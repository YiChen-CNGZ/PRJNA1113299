import requests
url = "https://apix.majorbio.com/project/get_project_contract?project_sn=4l9oueqkk1mvpmg4radfpacc68"
url
headers = {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
        "authorization": "373130354b534b4d784c4e316f4b427278474b425666497357494a4d503741746c4f32756330474a6471634e",
        "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "Windows",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36"
    }
requests.get(url2, headers=headers)
requests.get(url, headers=headers)
a = requests.get(url, headers=headers)
a.json
a.json()
url_login = "https://www.majorbio.com/api/web/login/passport/login-email"
url_login
user_info = {
    "contacter_id": 0,
    "account": "RNA@majorbio.com",
    "password": "dfghjk123GD",
    "captcha": "",
    "captcha_id":  "78eaaa7f345b3548ba51e44baf8eb87c",
    "remember": 0
}
user_info
respose = requests.post(url_login, json=user_info)
respose
respose.json()
respose.json()
respose.text
respose.headers
respose.cookies
respose = requests.post(url_login, json=user_info)
respose
respose.cookies
respose.token
respose.json
respose.json()
respose.cookies
respose.headers
set_cook = respose.headers
set_cook
set_cook.keys()
set_cook
type(set_cook)
a = dict(set_cook)
a
a['Set-Cookie']
dict(a['Set-Cookie'])
a['Set-Cookie'].split("; ")
a['Set-Cookie'].split("; ")
[cooks for cooks in  a['Set-Cookie'].split("; ") if "sso=" in cooks]
a = [cooks for cooks in  a['Set-Cookie'].split("; ") if "sso=" in cooks][0]
a.split("sso=")[1]
a.split("sso=")[1]
headers = {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
        "authorization": "373130354b534b4d784c4e316f4b427278474b425666497357494a4d503741746c4f32756330474a6471634e",
        "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "Windows",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36"
    }
headers = {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
        "authorization": a.split("sso=")[1],
        "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="96", "Google Chrome";v="96"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "Windows",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36"
    }
a = requests.get(url, headers=headers)
a
a.json()
ls -rlt
cd static/
ls -rlt
cd js/
