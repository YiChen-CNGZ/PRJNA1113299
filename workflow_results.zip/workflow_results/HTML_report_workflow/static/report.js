var report_data = {
    "category": {
        "category_3691": {
            "path": "", 
            "category_name": "结题报告"
        }, 
        "category_1489": {
            "path": "", 
            "category_name": "转录因子靶基因预测"
        }, 
        "category_1485": {
            "path": "", 
            "category_name": "转录因子预测"
        }, 
        "category_1487": {
            "path": "", 
            "category_name": "转录因子家族统计"
        }, 
        "category_1481": {
            "path": "", 
            "category_name": "模块分析"
        }, 
        "category_1483": {
            "path": "", 
            "category_name": "可视化分析"
        }, 
        "category_1369": {
            "category_name": "转录组组装概览"
        }, 
        "category_1365": {
            "category_name": "比对结果统计"
        }, 
        "category_1367": {
            "category_name": "转录组质量评估"
        }, 
        "category_1361": {
            "category_name": "原始数据统计"
        }, 
        "category_1363": {
            "category_name": "质控数据统计"
        }, 
        "category_1471": {
            "category_name": "差异可变剪切事件模式图"
        }, 
        "category_1473": {
            "path": "workflow_results/09AS/model_vs_control", 
            "path_exists": false, 
            "category_name": "差异可变剪切事件比较"
        }, 
        "category_1477": {
            "path": "", 
            "category_name": "数据预处理"
        }, 
        "category_3450": {
            "path": "", 
            "category_name": "目标SNP/Indel查询"
        }, 
        "category_1479": {
            "path": "", 
            "category_name": "模块识别"
        }, 
        "category_3020": {
            "path": "", 
            "category_name": "无尺度容适曲线与平均连通度曲线"
        }, 
        "category_1405": {
            "path": "workflow_results/08SNP", 
            "path_exists": true, 
            "category_name": "SNP/InDel分析"
        }, 
        "category_1407": {
            "path": "workflow_results/09AS", 
            "path_exists": true, 
            "category_name": "可变剪切分析"
        }, 
        "category_1401": {
            "path": "", 
            "category_name": "功能富集分析"
        }, 
        "category_1403": {
            "path": "workflow_results/06Express/ExpPCA", 
            "path_exists": true, 
            "category_name": "表达相关性分析"
        }, 
        "category_1399": {
            "path": "", 
            "category_name": "功能注释分析"
        }, 
        "category_1409": {
            "category_name": "蛋白互作网络分析"
        }, 
        "category_1359": {
            "category_name": "测序数据统计"
        }, 
        "category_4105": {
            "path": "", 
            "category_name": "差异可变剪切事件详情"
        }, 
        "category_4104": {
            "path": "", 
            "category_name": "差异可变剪切事件统计"
        }, 
        "category_1391": {
            "path": "workflow_results/06Express", 
            "path_exists": true, 
            "category_name": "样本关系分析"
        }, 
        "category_1373": {
            "path": "workflow_results/05Annotation/AnnotStatistics", 
            "path_exists": true, 
            "category_name": "功能注释统计"
        }, 
        "category_1393": {
            "category_name": "表达量差异统计"
        }, 
        "category_1417": {
            "category_name": "参考基因组信息"
        }, 
        "category_1415": {
            "category_name": "转录因子分析"
        }, 
        "category_1413": {
            "category_name": "WGCNA"
        }, 
        "category_1411": {
            "category_name": "iPath代谢通路分析"
        }, 
        "category_1395": {
            "path": "workflow_results/10GeneSet/07_GenesetVenn/", 
            "path_exists": true, 
            "category_name": "Venn分析"
        }, 
        "category_1389": {
            "path": "workflow_results/06Express/ExpAnnalysis", 
            "path_exists": true, 
            "category_name": "表达量统计"
        }, 
        "category_1419": {
            "category_name": "项目样本信息"
        }, 
        "category_1397": {
            "path": "workflow_results/06Express/ExpCorr", 
            "path_exists": true, 
            "category_name": "聚类分析"
        }, 
        "category_1337": {
            "path": "workflow_results/03Align", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "序列比对分析"
        }, 
        "category_1335": {
            "path": "workflow_results/02QC", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "测序数据质控"
        }, 
        "category_1333": {
            "path": "workflow_results/01Background", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "项目背景"
        }, 
        "category_1339": {
            "path": "workflow_results/04Assemble", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "转录本组装"
        }, 
        "category_1423": {
            "category_name": "分组方案管理"
        }, 
        "category_1421": {
            "category_name": "分析软件信息"
        }, 
        "category_1427": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "测序饱和度分析"
        }, 
        "category_1425": {
            "category_name": "基因集管理"
        }, 
        "category_1429": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "测序覆盖度分析"
        }, 
        "category_1439": {
            "path": "workflow_results/06Express/ExpVenn", 
            "path_exists": true, 
            "category_name": "样本间Venn分析"
        }, 
        "category_1435": {
            "path": "workflow_results/06Express/ExpAnnalysis", 
            "path_exists": true, 
            "category_name": "表达量矩阵"
        }, 
        "category_1437": {
            "path": "workflow_results/06Express/ExpAnnalysis", 
            "path_exists": true, 
            "category_name": "表达量分布"
        }, 
        "category_1431": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "不同区域Reads分布"
        }, 
        "category_1433": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "不同染色体Reads分布"
        }, 
        "category_3007": {
            "path": "", 
            "category_name": "文件获取"
        }, 
        "category_3003": {
            "path": "", 
            "category_name": "项目结果速览"
        }, 
        "category_2989": {
            "path": "", 
            "category_name": "可变剪切事件比较"
        }, 
        "category_2988": {
            "path": "", 
            "category_name": "可变剪切事件统计"
        }, 
        "category_1455": {
            "category_name": "富集弦图"
        }, 
        "category_2985": {
            "path": "", 
            "category_name": "批次效应评估"
        }, 
        "category_1371": {
            "category_name": "新转录本预测"
        }, 
        "category_2987": {
            "path": "", 
            "category_name": "可变剪切事件详情"
        }, 
        "category_2986": {
            "path": "", 
            "category_name": "可变剪切分析-ASprofile"
        }, 
        "category_1449": {
            "path": "workflow_results/10GeneSet/04_KEGG_Annotation", 
            "path_exists": true, 
            "category_name": "KEGG注释分析"
        }, 
        "category_1351": {
            "exists": true, 
            "category_name": "基因结构分析"
        }, 
        "category_3449": {
            "path": "", 
            "category_name": "表达量矩阵"
        }, 
        "category_1353": {
            "path": "", 
            "category_name": "高级分析"
        }, 
        "category_1441": {
            "path": "workflow_results/06Express/ExpCorr", 
            "path_exists": true, 
            "category_name": "样本间相关性分析"
        }, 
        "category_1443": {
            "path": "workflow_results/06Express/ExpPCA", 
            "path_exists": true, 
            "category_name": "样本间PCA分析"
        }, 
        "category_3152": {
            "path": "", 
            "category_name": "GSEA分析"
        }, 
        "category_1445": {
            "path": "workflow_results/10GeneSet/02_COG_Annotation", 
            "path_exists": true, 
            "category_name": "COG注释分析"
        }, 
        "category_1447": {
            "path": "workflow_results/10GeneSet/03_GO_Annotation", 
            "path_exists": true, 
            "category_name": "GO注释分析"
        }, 
        "category_2992": {
            "path": "", 
            "category_name": "基因融合Venn分析"
        }, 
        "category_2990": {
            "path": "", 
            "category_name": "基因融合"
        }, 
        "category_2991": {
            "path": "", 
            "category_name": "基因融合详情"
        }, 
        "category_1347": {
            "path": "workflow_results/07DiffExpress_G", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "表达量差异分析"
        }, 
        "category_1345": {
            "path": "workflow_results/06Express", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "表达量分析"
        }, 
        "category_3384": {
            "path": "", 
            "category_name": "序列批量下载"
        }, 
        "category_1453": {
            "path": "workflow_results/10GeneSet/06_KEGG_Enrich", 
            "path_exists": true, 
            "category_name": "KEGG富集分析"
        }, 
        "category_1451": {
            "path": "workflow_results/10GeneSet/05_GO_Enrich", 
            "path_exists": true, 
            "category_name": "GO富集分析"
        }, 
        "category_1457": {
            "category_name": "GO富集有向无环图"
        }, 
        "category_1349": {
            "path": "workflow_results/10GeneSet", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "基因集分析"
        }, 
        "category_2361": {
            "path": "", 
            "category_name": "时序表达趋势分析"
        }, 
        "category_2360": {
            "path": "", 
            "category_name": "时序分析"
        }, 
        "category_2363": {
            "path": "", 
            "category_name": "GSEA分析"
        }, 
        "category_2362": {
            "path": "", 
            "category_name": "时序差异分析"
        }, 
        "category_2367": {
            "path": "", 
            "category_name": "功能注释与查询"
        }, 
        "category_1459": {
            "category_name": "SNP/InDel注释详情"
        }, 
        "category_1467": {
            "category_name": "可变剪切事件统计"
        }, 
        "category_1465": {
            "path": "workflow_results/09AS", 
            "path_exists": true, 
            "category_name": "差异可变剪切事件详情"
        }, 
        "category_1463": {
            "category_name": "SNP统计"
        }, 
        "category_1461": {
            "category_name": "SNP/InDel不同区域分布"
        }, 
        "category_1469": {
            "category_name": "差异可变剪切事件统计"
        }, 
        "category_2373": {
            "path": "", 
            "category_name": "功能查询"
        }, 
        "category_2370": {
            "path": "", 
            "category_name": "功能注释详情"
        }, 
        "category_2371": {
            "path": "", 
            "category_name": "功能注释统计"
        }, 
        "category_2376": {
            "path": "", 
            "category_name": "GSEA分析-详情"
        }, 
        "category_2377": {
            "path": "", 
            "category_name": "可变剪切事件统计"
        }, 
        "category_2374": {
            "path": "", 
            "category_name": "功能查询"
        }, 
        "category_2375": {
            "path": "", 
            "category_name": "时序表达趋势分析-详情"
        }, 
        "category_2378": {
            "path": "", 
            "category_name": "kegg注释"
        }, 
        "category_2379": {
            "path": "", 
            "category_name": "kegg注释"
        }
    }, 
    "group_dict": {
        "HS": [
            "HS_1", 
            "HS_2", 
            "HS_3"
        ], 
        "LS": [
            "LS_1", 
            "LS_2", 
            "LS_3"
        ]
    }, 
    "dir_data": [
        {
            "text": "01Background           项目背景结果目录", 
            "opened": true, 
            "dir": "01Background", 
            "children": [
                {
                    "text": ".*.genome_info.xls        基因组注释信息表", 
                    "opened": true, 
                    "dir": "01Background/.*.genome_info.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "sample_info.xls        样本信息表", 
                    "opened": true, 
                    "dir": "01Background/sample_info.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "software_info.xls        软件信息表", 
                    "opened": true, 
                    "dir": "01Background/software_info.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "run_parameter.txt        分析参数日志", 
                    "opened": true, 
                    "dir": "01Background/run_parameter.txt", 
                    "icon": "fa fa-file-text"
                }
            ]
        }, 
        {
            "text": "02QC           测序数据质控结果目录", 
            "opened": true, 
            "dir": "02QC", 
            "children": [
                {
                    "text": ".*raw_qc_qual.box.pdf        原始数据碱基质量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*raw_qc_qual.box.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*raw_qc_error.line.pdf        原始数据碱基错误率分布图", 
                    "opened": true, 
                    "dir": "02QC/.*raw_qc_error.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*raw_qc_base.line.pdf        原始数据碱基含量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*raw_qc_base.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*clean_qc_qual.box.pdf        质控数据碱基质量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*clean_qc_qual.box.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*clean_qc_error.line.pdf        质控数据碱基错误率分布图", 
                    "opened": true, 
                    "dir": "02QC/.*clean_qc_error.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*clean_qc_base.line.pdf        质控数据碱基含量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*clean_qc_base.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "qc_pdf.tar.gz        测序数据统计图", 
                    "opened": true, 
                    "dir": "02QC/qc_pdf.tar.gz", 
                    "icon": "fa fa-file-zip-o"
                }, 
                {
                    "text": "rawdata_statistics.xls        原始数据统计表", 
                    "opened": true, 
                    "dir": "02QC/rawdata_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "cleandata_statistics.xls        质控数据统计表", 
                    "opened": true, 
                    "dir": "02QC/cleandata_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "qc_data_statistics.xls        质控数据统计表", 
                    "opened": true, 
                    "dir": "02QC/qc_data_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }
            ]
        }, 
        {
            "text": "03Align           序列比对结果目录", 
            "opened": true, 
            "dir": "03Align", 
            "children": [
                {
                    "text": "align_stat.xls        比对结果统计表", 
                    "opened": true, 
                    "dir": "03Align/align_stat.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "QualityAssessment        比对结果整体评估", 
                    "opened": true, 
                    "dir": "03Align/QualityAssessment", 
                    "children": [
                        {
                            "text": ".*align.satu.*.pdf        测序饱和度曲线图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align.satu.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*align_pos_dist.*.pdf        不同区域Reads分布统计饼图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align_pos_dist.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*align_coverage.*.pdf        测序覆盖度分布图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align_coverage.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*align_chr_dist.*.pdf        不同染色体Reads分布统计柱状图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align_chr_dist.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "align_pdf.tar.gz        转录组质量评估图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/align_pdf.tar.gz", 
                            "icon": "fa fa-file-zip-o"
                        }, 
                        {
                            "text": "chr_distribution.xls        不同染色体Reads分布统计表", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/chr_distribution.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "region_distribution.xls        不同区域Reads分布统计表", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/region_distribution.xls", 
                            "icon": "fa fa-file-excel-o"
                        }
                    ]
                }
            ]
        }, 
        {
            "text": "04Assemble           组装结果目录", 
            "opened": true, 
            "dir": "04Assemble", 
            "children": [
                {
                    "text": "all.assemble.*.column.pdf        转录本长度分布柱状图", 
                    "opened": true, 
                    "dir": "04Assemble/all.assemble.*.column.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "all.assemble.*.pie.pdf        转录本长度分布饼图", 
                    "opened": true, 
                    "dir": "04Assemble/all.assemble.*.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*assemble_relation.*.columns.pdf        基因与转录本关系柱状图", 
                    "opened": true, 
                    "dir": "04Assemble/.*assemble_relation.*.columns.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*assemble_relation.*.line.pdf        外显子与转录本关系曲线图", 
                    "opened": true, 
                    "dir": "04Assemble/.*assemble_relation.*.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "length_distribution.200.xls        转录本长度分布表-步长200", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.200.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "length_distribution.300.xls        转录本长度分布表-步长300", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.300.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "length_distribution.600.xls        转录本长度分布表-步长600", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.600.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "length_distribution.1000.xls        转录本长度分布表-步长1000", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.1000.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "classcode_statistics.xls        新转录本类型统计表", 
                    "opened": true, 
                    "dir": "04Assemble/classcode_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "Sequence        转录本序列文件", 
                    "opened": true, 
                    "dir": "04Assemble/Sequence", 
                    "children": [
                        {
                            "text": "all_transcripts.fa        组装结果序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_transcripts.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "new_transcripts.fa        新转录本序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/new_transcripts.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "all_cds.fa        CDS序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_cds.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "all_pep.fa        蛋白序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_pep.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "all_id.xls        基因转录本蛋白ID对应关系文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_id.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "all_transcripts.gtf        组装结果GTF文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_transcripts.gtf", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "new_transcripts.gtf        新转录本GTF文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/new_transcripts.gtf", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "trans2gene.txt        转录本与基因的对应关系文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/trans2gene.txt", 
                            "icon": "fa fa-file-text"
                        }
                    ]
                }
            ]
        }, 
        {
            "text": "06Express           表达量分析结果目录", 
            "opened": true, 
            "dir": "06Express", 
            "children": [
                {
                    "text": "ExpAnnalysis        表达定量结果", 
                    "opened": true, 
                    "dir": "06Express/ExpAnnalysis", 
                    "children": [
                        {
                            "text": ".*exp_distribution.box.pdf        表达量分布盒型图", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/.*exp_distribution.box.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*exp_distribution.density.pdf        表达量分布密度图", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/.*exp_distribution.density.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*exp_distribution.violin.pdf        表达量分布小提琴图", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/.*exp_distribution.violin.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "gene.count.matrix.xls        基因count表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.count.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.tpm.matrix.xls        基因tpm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.tpm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.fpkm.matrix.xls        基因fpkm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.fpkm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.count.matrix.xls        转录本count表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.count.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.tpm.matrix.xls        转录本tpm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.tpm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.fpkm.matrix.xls        转录本fpkm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.fpkm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.tpm.matrix.annot.xls        基因tpm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.tpm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.fpkm.matrix.annot.xls        基因fpkm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.fpkm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.count.matrix.annot.xls        基因count表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.count.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.tpm.matrix.annot.xls        转录本tpm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.tpm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.fpkm.matrix.annot.xls        转录本fpkm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.fpkm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.count.matrix.annot.xls        转录本count表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.count.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }
                    ]
                }, 
                {
                    "text": "ExpVenn        样本间Venn分析", 
                    "opened": true, 
                    "dir": "06Express/ExpVenn", 
                    "children": [
                        {
                            "text": ".*.venn.pdf        样本间venn图", 
                            "opened": true, 
                            "dir": "06Express/ExpVenn/.*.venn.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*.upset.pdf        样本间upset图", 
                            "opened": true, 
                            "dir": "06Express/ExpVenn/.*.upset.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }
                    ]
                }, 
                {
                    "text": "ExpCor        样本间相关性分析", 
                    "opened": true, 
                    "dir": "06Express/ExpCor"
                }, 
                {
                    "text": "ExpPCA        样本间PCA分析", 
                    "opened": true, 
                    "dir": "06Express/ExpPCA", 
                    "children": [
                        {
                            "text": ".*all.exp_relation.*.pdf        样本间PCA图", 
                            "opened": true, 
                            "dir": "06Express/ExpPCA/.*all.exp_relation.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "PCA.xls        样本间PCA分析结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpPCA/PCA.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "Explained_variance_ratio.xls        样本间PCA主成分解释表", 
                            "opened": true, 
                            "dir": "06Express/ExpPCA/Explained_variance_ratio.xls", 
                            "icon": "fa fa-file-excel-o"
                        }
                    ]
                }
            ]
        }, 
        {
            "text": "07DiffExpress_G           表达量差异分析结果目录", 
            "opened": true, 
            "dir": "07DiffExpress_G", 
            "children": [
                {
                    "text": ".*_vs_.*.xls        差异分析结果表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*_vs_.*.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": ".*.DE.list        差异基因列表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*.DE.list"
                }, 
                {
                    "text": ".*summary.*.xls        差异表达基因统计表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*summary.*.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": ".*total_diff_stat.*.xls        差异表达基因详情总表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*total_diff_stat.*.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "all.diffexp.*.pdf        表达量差异统计图", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/all.diffexp.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*diffexp.volcano.*.pdf        表达量差异火山图", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*diffexp.volcano.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*diffexp.scatter.*.pdf        表达量差异散点图", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*diffexp.scatter.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }
            ]
        }, 
        {
            "text": "08SNP           SNP/InDel分析结果目录", 
            "opened": true, 
            "dir": "08SNP", 
            "children": [
                {
                    "text": ".*snp.pos_stat.pie.pdf        SNP不同区域分布饼图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.pos_stat.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.type_stat.column.pdf        SNP类型统计图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.type_stat.column.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.type_stat.pie.pdf        SNP类型饼图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.type_stat.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.depth_stat.column.pdf        SNP深度统计图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.depth_stat.column.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.depth_stat.pie.pdf        SNP深度饼图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.depth_stat.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "SNP_vcf        SNP鉴定vcf结果目录", 
                    "opened": true, 
                    "dir": "08SNP/SNP_vcf"
                }, 
                {
                    "text": "snp_pdf.tar.gz        SNP统计图", 
                    "opened": true, 
                    "dir": "08SNP/snp_pdf.tar.gz", 
                    "icon": "fa fa-file-zip-o"
                }, 
                {
                    "text": "snp_anno.xls        SNP分析结果注释详情表", 
                    "opened": true, 
                    "dir": "08SNP/snp_anno.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "indel_anno.xls        InDel分析结果注释详情表", 
                    "opened": true, 
                    "dir": "08SNP/indel_anno.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_transition_tranversion_statistics.xls        SNP类型统计结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_transition_tranversion_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_freq_statistics.xls        SNP频率统计结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_freq_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_depth_statistics.xls        SNP深度统计结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_depth_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_position_distribution.xls        SNP不同区域布析结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_position_distribution.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "indel_position_distribution.xls        InDel不同区域布析结果表", 
                    "opened": true, 
                    "dir": "08SNP/indel_position_distribution.xls", 
                    "icon": "fa fa-file-excel-o"
                }
            ]
        }, 
        {
            "text": "09AS           可变剪切分析结果目录", 
            "opened": true, 
            "dir": "09AS", 
            "children": [
                {
                    "text": ".*_vs_.*        差异组别", 
                    "opened": true, 
                    "dir": "09AS/.*_vs_.*", 
                    "children": [
                        {
                            "text": "JC        JC定量", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/JC", 
                            "children": [
                                {
                                    "text": "SE.detail.xls        SE可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/SE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "MXE.detail.xls        MXE可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/MXE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A3SS.detail.xls        A3SS可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/A3SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A5SS.detail.xls        A5SS可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/A5SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "RI.detail.xls        RI可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/RI.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }
                            ]
                        }, 
                        {
                            "text": "JCEC        JCEC定量", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/JCEC", 
                            "children": [
                                {
                                    "text": "SE.detail.xls        SE可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/SE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "MXE.detail.xls        MXE可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/MXE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A3SS.detail.xls        A3SS可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/A3SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A5SS.detail.xls        A5SS可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/A5SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "RI.detail.xls        RI可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/RI.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }
                            ]
                        }, 
                        {
                            "text": "diff_event_stats.xls        组内差异可变剪切事件统计表", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/diff_event_stats.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "diff_pattern_stats.JC.xls        组内差异可变剪切模式变化统计表（JC）", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/diff_pattern_stats.JC.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "diff_pattern_stats.JCEC.xls        组内差异可变剪切模式变化统计表（JCEC）", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/diff_pattern_stats.JCEC.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": ".*splice_stat.*pie.pdf        组内差异可变剪切事件统计饼状图", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/.*splice_stat.*pie.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*splice_stat.*column.pdf        组内差异可变剪切事件统计柱状图", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/.*splice_stat.*column.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "rmats_pdf.tar.gz        差异可变剪切事件统计图", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/rmats_pdf.tar.gz", 
                            "icon": "fa fa-file-zip-o"
                        }
                    ]
                }, 
                {
                    "text": ".*splice_stat.*.pdf        可变剪切事件统计图", 
                    "opened": true, 
                    "dir": "09AS/.*splice_stat.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "event_type.JC.xls        可变剪切事件统计表（JC）", 
                    "opened": true, 
                    "dir": "09AS/event_type.JC.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "event_type.JCEC.xls        可变剪切事件统计表（JCEC）", 
                    "opened": true, 
                    "dir": "09AS/event_type.JCEC.xls", 
                    "icon": "fa fa-file-excel-o"
                }
            ]
        }, 
        {
            "text": "10GeneSet           基因集分析结果目录", 
            "opened": true, 
            "dir": "10GeneSet", 
            "children": [
                {
                    "text": "07_GenesetVenn        差异基因集venn分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/07_GenesetVenn", 
                    "children": [
                        {
                            "text": "*.pdf        差异基因集venn图", 
                            "opened": true, 
                            "dir": "10GeneSet/07_GenesetVenn/*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }
                    ]
                }, 
                {
                    "text": "01_Cluster_Analysis        基因集聚类分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/01_Cluster_Analysis", 
                    "children": [
                        {
                            "text": "*        基因集聚类分析结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/01_Cluster_Analysis/*", 
                            "children": [
                                {
                                    "text": "subcluster_xls.tar.gz        聚类详情表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/subcluster_xls.tar.gz", 
                                    "icon": "fa fa-file-zip-o"
                                }, 
                                {
                                    "text": "seq.cluster_tree.txt        基因/转录本聚类树文件", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/seq.cluster_tree.txt", 
                                    "icon": "fa fa-file-text"
                                }, 
                                {
                                    "text": "seq.kmeans_cluster.txt        基因/转录本聚类树文件", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/seq.kmeans_cluster.txt", 
                                    "icon": "fa fa-file-text"
                                }, 
                                {
                                    "text": "sample.cluster_tree.txt        样本聚类树文件", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/sample.cluster_tree.txt", 
                                    "icon": "fa fa-file-text"
                                }, 
                                {
                                    "text": "expression_matrix.xls        聚类热图分析表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/expression_matrix.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "seq.subcluster_*.xls        子聚类分析表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/seq.subcluster_*.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "heatmap.pdf        聚类热图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/heatmap.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*heat_corr.pdf        聚类热图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/*heat_corr.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*.line.pdf        子聚类折线图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/*.line.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "02_COG_Annotation        基因集聚COG分类结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/02_COG_Annotation", 
                    "children": [
                        {
                            "text": "*        基因集聚COG分类结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/02_COG_Annotation/*", 
                            "children": [
                                {
                                    "text": "cog_class_stat.xls        COG分类统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/02_COG_Annotation/*/cog_class_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*.pdf        COG分类统计图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/02_COG_Annotation/*/*.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "03_GO_Annotation        基因集GO分类结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/03_GO_Annotation", 
                    "children": [
                        {
                            "text": "*        基因集GO分类结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/03_GO_Annotation/*", 
                            "children": [
                                {
                                    "text": "go_class_stat.xls        GO分类统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/03_GO_Annotation/*/go_class_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*.pdf        GO分类统计图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/03_GO_Annotation/*/*.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "04_KEGG_Annotation        基因集KEGG分类结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/04_KEGG_Annotation", 
                    "children": [
                        {
                            "text": "*        基因集KEGG分类结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/04_KEGG_Annotation/*", 
                            "children": [
                                {
                                    "text": "pathways.tar.gz        KEGG通路图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/04_KEGG_Annotation/*/pathways.tar.gz", 
                                    "icon": "fa fa-file-zip-o"
                                }, 
                                {
                                    "text": "kegg_class_stat.xls        Pathway分类统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/04_KEGG_Annotation/*/kegg_class_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*.pdf        KEGG分类统计图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/04_KEGG_Annotation/*/*.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "05_GO_Enrich        基因集GO富集分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/05_GO_Enrich", 
                    "children": [
                        {
                            "text": "*        基因集GO富集分析结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/05_GO_Enrich/*", 
                            "children": [
                                {
                                    "text": "go_enrich_stat.xls        GO富集分析统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/go_enrich_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*bar.pdf        GO富集分析柱形图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*bar.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*bar_line.pdf        GO富集分析柱形图(带折线)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*bar_line.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble.pdf        GO富集分析气泡图(单基因集)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*buble.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble2.pdf        GO富集分析气泡图(分散型)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*buble2.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "06_KEGG_Enrich        基因集KEGG富集分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/06_KEGG_Enrich", 
                    "children": [
                        {
                            "text": "*        基因集KEGG富集分析结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/06_KEGG_Enrich/*", 
                            "children": [
                                {
                                    "text": "kegg_enrich_stat.xls        KEGG富集分析统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/kegg_enrich_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "pathways.tar.gz        KEGG富集通路图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/pathways.tar.gz", 
                                    "icon": "fa fa-file-zip-o"
                                }, 
                                {
                                    "text": "*bar.pdf        KEGG富集分析柱形图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*bar.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*bar_line.pdf        KEGG富集分析柱形图(带折线)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*bar_line.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble.pdf        KEGG富集分析气泡图(单基因集)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*buble.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble2.pdf        KEGG富集分析气泡图(分散型)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*buble2.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ], 
    "image": {
        "image_5883": {
            "image_file": {
                "HS_1": "workflow_results/08SNP/HS_1.snp.type_stat.column.jpg", 
                "HS_2": "workflow_results/08SNP/HS_2.snp.type_stat.column.jpg", 
                "HS_3": "workflow_results/08SNP/HS_3.snp.type_stat.column.jpg", 
                "LS_1": "workflow_results/08SNP/LS_1.snp.type_stat.column.jpg", 
                "LS_2": "workflow_results/08SNP/LS_2.snp.type_stat.column.jpg", 
                "LS_3": "workflow_results/08SNP/LS_3.snp.type_stat.column.jpg"
            }, 
            "image_title": "SNP类型统计柱状图"
        }, 
        "image_6261": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/02_COG_Annotation/HS_vs_LS_G/HS_vs_LS_G.cog_annot.gene_set.column.jpg"
            }, 
            "image_title": "COG分类统计柱状图"
        }, 
        "image_7661": {
            "image_file": {
                "HS_vs_LS": "workflow_results/07DiffExpress_G/HS_vs_LS.diffexp.volcano.jpg"
            }, 
            "image_title": "表达量差异火山图"
        }, 
        "image_6055": {
            "image_file": "workflow_results/06Express/ExpPCA/all.exp_relation_pca.scatter.jpg", 
            "image_title": "PCA图"
        }, 
        "image_6095": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/03_GO_Annotation/HS_vs_LS_G/HS_vs_LS_G.go_annot.gene_set.column.jpg"
            }, 
            "image_title": "GO分类统计柱形图"
        }, 
        "image_5987": {
            "image_file": "workflow_results/04Assemble/all.assemble_new.pie.jpg", 
            "image_title": "新转录本类型分布饼状图"
        }, 
        "image_5989": {
            "image_file": "workflow_results/04Assemble/all.assemble_len.column.jpg", 
            "image_title": "转录本长度分布柱状图"
        }, 
        "image_6019": {
            "image_file": {
                "HS_1": "workflow_results/02QC/HS_1.clean_qc_base.line.jpg", 
                "HS_2": "workflow_results/02QC/HS_2.clean_qc_base.line.jpg", 
                "HS_3": "workflow_results/02QC/HS_3.clean_qc_base.line.jpg", 
                "LS_1": "workflow_results/02QC/LS_1.clean_qc_base.line.jpg", 
                "LS_2": "workflow_results/02QC/LS_2.clean_qc_base.line.jpg", 
                "LS_3": "workflow_results/02QC/LS_3.clean_qc_base.line.jpg"
            }, 
            "image_title": "碱基（组成）分布图"
        }, 
        "image_6009": {
            "image_file": {
                "HS_1": "workflow_results/02QC/HS_1.raw_qc_qual.curve.jpg", 
                "HS_2": "workflow_results/02QC/HS_2.raw_qc_qual.curve.jpg", 
                "HS_3": "workflow_results/02QC/HS_3.raw_qc_qual.curve.jpg", 
                "LS_1": "workflow_results/02QC/LS_1.raw_qc_qual.curve.jpg", 
                "LS_2": "workflow_results/02QC/LS_2.raw_qc_qual.curve.jpg", 
                "LS_3": "workflow_results/02QC/LS_3.raw_qc_qual.curve.jpg"
            }, 
            "image_title": "碱基质量分布图"
        }, 
        "image_10234": {
            "image_file": {
                "HS_vs_LS": "workflow_results/09AS/HS_vs_LS/HS_vs_LS_JC.diff_splice_stat.column.jpg"
            }, 
            "image_title": "差异可变剪接模式变化统计柱形图"
        }, 
        "image_10233": {
            "image_file": {
                "HS_vs_LS": "workflow_results/09AS/HS_vs_LS/HS_vs_LS_JC.diff_splice_stat.pie.jpg"
            }, 
            "image_title": "差异可变剪切事件统计饼状图"
        }, 
        "image_6053": {
            "image_file": "workflow_results/06Express/ExpCorr/all.exp.heat_corr.jpg", 
            "image_title": "样本间相关性热图"
        }, 
        "image_6011": {
            "image_file": {
                "HS_1": "workflow_results/02QC/HS_1.raw_qc_error.line.jpg", 
                "HS_2": "workflow_results/02QC/HS_2.raw_qc_error.line.jpg", 
                "HS_3": "workflow_results/02QC/HS_3.raw_qc_error.line.jpg", 
                "LS_1": "workflow_results/02QC/LS_1.raw_qc_error.line.jpg", 
                "LS_2": "workflow_results/02QC/LS_2.raw_qc_error.line.jpg", 
                "LS_3": "workflow_results/02QC/LS_3.raw_qc_error.line.jpg"
            }, 
            "image_title": "碱基错误率分布图"
        }, 
        "image_6051": {
            "image_file": "workflow_results/06Express/ExpVenn/all.exp.venn.jpg", 
            "image_title": "样本表达基因Venn图"
        }, 
        "image_6013": {
            "image_file": {
                "HS_1": "workflow_results/02QC/HS_1.raw_qc_base.line.jpg", 
                "HS_2": "workflow_results/02QC/HS_2.raw_qc_base.line.jpg", 
                "HS_3": "workflow_results/02QC/HS_3.raw_qc_base.line.jpg", 
                "LS_1": "workflow_results/02QC/LS_1.raw_qc_base.line.jpg", 
                "LS_2": "workflow_results/02QC/LS_2.raw_qc_base.line.jpg", 
                "LS_3": "workflow_results/02QC/LS_3.raw_qc_base.line.jpg"
            }, 
            "image_title": "碱基（组成）分布图"
        }, 
        "image_6015": {
            "image_file": {
                "HS_1": "workflow_results/02QC/HS_1.clean_qc_qual.curve.jpg", 
                "HS_2": "workflow_results/02QC/HS_2.clean_qc_qual.curve.jpg", 
                "HS_3": "workflow_results/02QC/HS_3.clean_qc_qual.curve.jpg", 
                "LS_1": "workflow_results/02QC/LS_1.clean_qc_qual.curve.jpg", 
                "LS_2": "workflow_results/02QC/LS_2.clean_qc_qual.curve.jpg", 
                "LS_3": "workflow_results/02QC/LS_3.clean_qc_qual.curve.jpg"
            }, 
            "image_title": "碱基质量分布图"
        }, 
        "image_6137": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/06_KEGG_Enrich/HS_vs_LS_G/HS_vs_LS_G.kegg_enrich.gene_set.buble.jpg"
            }, 
            "image_title": "KEGG富集分析气泡图"
        }, 
        "image_6017": {
            "image_file": {
                "HS_1": "workflow_results/02QC/HS_1.clean_qc_error.line.jpg", 
                "HS_2": "workflow_results/02QC/HS_2.clean_qc_error.line.jpg", 
                "HS_3": "workflow_results/02QC/HS_3.clean_qc_error.line.jpg", 
                "LS_1": "workflow_results/02QC/LS_1.clean_qc_error.line.jpg", 
                "LS_2": "workflow_results/02QC/LS_2.clean_qc_error.line.jpg", 
                "LS_3": "workflow_results/02QC/LS_3.clean_qc_error.line.jpg"
            }, 
            "image_title": "碱基错误率分布图"
        }, 
        "image_6135": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/06_KEGG_Enrich/HS_vs_LS_G/HS_vs_LS_G.kegg_enrich.gene_set.bar.jpg"
            }, 
            "image_title": "KEGG富集分析柱状图"
        }, 
        "image_5997": {
            "image_file": "workflow_results/05Annotation/AnnotStatistics/annot_gene_stat.column.jpg", 
            "image_title": "转录组功能分类统计柱状图"
        }, 
        "image_8576": {
            "image_file": "workflow_results/09AS/all_JCsplice_stat.column.jpg", 
            "image_title": "可变剪切事件统计图"
        }, 
        "image_6087": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/01_Cluster_Analysis/HS_vs_LS_G/geneset.cluster.heat_corr.jpg"
            }, 
            "image_title": "聚类热图"
        }, 
        "image_6263": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/02_COG_Annotation/HS_vs_LS_G/HS_vs_LS_G.cog_annot.gene_set.column.jpg"
            }, 
            "image_title": "COG分类统计柱状图"
        }, 
        "image_5891": {
            "image_file": {
                "HS_1": "workflow_results/08SNP/HS_1.snp.depth_stat.column.jpg", 
                "HS_2": "workflow_results/08SNP/HS_2.snp.depth_stat.column.jpg", 
                "HS_3": "workflow_results/08SNP/HS_3.snp.depth_stat.column.jpg", 
                "LS_1": "workflow_results/08SNP/LS_1.snp.depth_stat.column.jpg", 
                "LS_2": "workflow_results/08SNP/LS_2.snp.depth_stat.column.jpg", 
                "LS_3": "workflow_results/08SNP/LS_3.snp.depth_stat.column.jpg"
            }, 
            "image_title": "SNP深度统计柱状图"
        }, 
        "image_5991": {
            "image_file": "workflow_results/04Assemble/new.assemble_relation_g2t.columns.jpg", 
            "image_title": "基因与转录本关系柱状图"
        }, 
        "image_5993": {
            "image_file": "workflow_results/04Assemble/new.assemble_relation_t2e.line.jpg", 
            "image_title": "外显子与转录本关系曲线图"
        }, 
        "image_6027": {
            "image_file": {
                "HS_1": "workflow_results/03Align/QualityAssessment/HS_1.align_chr_dist.bar.jpg", 
                "HS_2": "workflow_results/03Align/QualityAssessment/HS_2.align_chr_dist.bar.jpg", 
                "HS_3": "workflow_results/03Align/QualityAssessment/HS_3.align_chr_dist.bar.jpg", 
                "LS_1": "workflow_results/03Align/QualityAssessment/LS_1.align_chr_dist.bar.jpg", 
                "LS_2": "workflow_results/03Align/QualityAssessment/LS_2.align_chr_dist.bar.jpg", 
                "LS_3": "workflow_results/03Align/QualityAssessment/LS_3.align_chr_dist.bar.jpg"
            }, 
            "image_title": "Reads在不同染色体分布柱状图"
        }, 
        "image_8571": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/06_KEGG_Enrich/HS_vs_LS_G/HS_vs_LS_G.kegg_enrich.gene_set.bar_line.jpg"
            }, 
            "image_title": "KEGG富集分析柱形图（带折线））"
        }, 
        "image_9571": {
            "image_file": "workflow_results/07DiffExpress_G/all.diffexp_summary.bar2.jpg", 
            "image_title": "表达量差异统计图"
        }, 
        "image_9570": {
            "image_file": "workflow_results/07DiffExpress_G/all.diffexp_summary.bar.jpg", 
            "image_title": "表达量差异统计图"
        }, 
        "image_6147": {
            "image_file": {
                "HS_1": "workflow_results/08SNP/HS_1.snp.pos_stat.pie.jpg", 
                "HS_2": "workflow_results/08SNP/HS_2.snp.pos_stat.pie.jpg", 
                "HS_3": "workflow_results/08SNP/HS_3.snp.pos_stat.pie.jpg", 
                "LS_1": "workflow_results/08SNP/LS_1.snp.pos_stat.pie.jpg", 
                "LS_2": "workflow_results/08SNP/LS_2.snp.pos_stat.pie.jpg", 
                "LS_3": "workflow_results/08SNP/LS_3.snp.pos_stat.pie.jpg"
            }, 
            "image_title": "不同区域分布饼图"
        }, 
        "image_6089": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/01_Cluster_Analysis/HS_vs_LS_G/cluster.10.line.jpg"
            }, 
            "image_title": "子聚类趋势图"
        }, 
        "image_7659": {
            "image_file": {
                "HS_vs_LS": "workflow_results/07DiffExpress_G/HS_vs_LS.diffexp.scatter.jpg"
            }, 
            "image_title": "表达量差异散点图"
        }, 
        "image_6047": {
            "image_file": {
                "samples": "workflow_results/06Express/ExpAnnalysis/G_samples.exp_distribution.box.jpg", 
                "groups": "workflow_results/06Express/ExpAnnalysis/G_groups.exp_distribution.box.jpg"
            }, 
            "image_title": "表达量分布盒形图"
        }, 
        "image_6045": {
            "image_file": {
                "samples": "workflow_results/06Express/ExpAnnalysis/G_samples.exp_distribution.density.jpg", 
                "groups": "workflow_results/06Express/ExpAnnalysis/G_groups.exp_distribution.density.jpg"
            }, 
            "image_title": "表达量分布密度图"
        }, 
        "image_6139": {
            "image_file": {
                "HS_vs_LS": "workflow_results/10GeneSet/06_KEGG_Enrich/HS_vs_LS_G/HS_vs_LS_G.kegg_enrich.gene_set.buble2.jpg"
            }, 
            "image_title": "KEGG富集分析气泡图（分散型）"
        }, 
        "image_6025": {
            "image_file": {
                "HS_1": "workflow_results/03Align/QualityAssessment/HS_1.align_pos_dist.pie.jpg", 
                "HS_2": "workflow_results/03Align/QualityAssessment/HS_2.align_pos_dist.pie.jpg", 
                "HS_3": "workflow_results/03Align/QualityAssessment/HS_3.align_pos_dist.pie.jpg", 
                "LS_1": "workflow_results/03Align/QualityAssessment/LS_1.align_pos_dist.pie.jpg", 
                "LS_2": "workflow_results/03Align/QualityAssessment/LS_2.align_pos_dist.pie.jpg", 
                "LS_3": "workflow_results/03Align/QualityAssessment/LS_3.align_pos_dist.pie.jpg"
            }, 
            "image_title": "Reads在参考基因组不同区域的分布饼状图"
        }, 
        "image_6049": {
            "image_file": {
                "samples": "workflow_results/06Express/ExpAnnalysis/G_samples.exp_distribution.violin.jpg", 
                "groups": "workflow_results/06Express/ExpAnnalysis/G_groups.exp_distribution.violin.jpg"
            }, 
            "image_title": "表达量分布小提琴图"
        }, 
        "image_6021": {
            "image_file": {
                "HS_1": "workflow_results/03Align/QualityAssessment/HS_1.align.satu.line.jpg", 
                "HS_2": "workflow_results/03Align/QualityAssessment/HS_2.align.satu.line.jpg", 
                "HS_3": "workflow_results/03Align/QualityAssessment/HS_3.align.satu.line.jpg", 
                "LS_1": "workflow_results/03Align/QualityAssessment/LS_1.align.satu.line.jpg", 
                "LS_2": "workflow_results/03Align/QualityAssessment/LS_2.align.satu.line.jpg", 
                "LS_3": "workflow_results/03Align/QualityAssessment/LS_3.align.satu.line.jpg"
            }, 
            "image_title": "测序饱和度曲线图"
        }, 
        "image_6023": {
            "image_file": {
                "HS_1": "workflow_results/03Align/QualityAssessment/HS_1.align_coverage.line.jpg", 
                "HS_2": "workflow_results/03Align/QualityAssessment/HS_2.align_coverage.line.jpg", 
                "HS_3": "workflow_results/03Align/QualityAssessment/HS_3.align_coverage.line.jpg", 
                "LS_1": "workflow_results/03Align/QualityAssessment/LS_1.align_coverage.line.jpg", 
                "LS_2": "workflow_results/03Align/QualityAssessment/LS_2.align_coverage.line.jpg", 
                "LS_3": "workflow_results/03Align/QualityAssessment/LS_3.align_coverage.line.jpg"
            }, 
            "image_title": "测序覆盖度分布图"
        }
    }, 
    "database_list": [
        {
            "software_database": "TransDecoder", 
            "source": "http://transdecoder.github.io/", 
            "version": "Version 5.5.0", 
            "usage": "多类数据库注释比较分析等"
        }, 
        {
            "software_database": "SeqPrep", 
            "source": "https://github.com/jstjohn/SeqPrep", 
            "version": "--", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "edgeR", 
            "source": "http://bioconductor.org/packages/stats/bioc/edgeR/", 
            "version": "Version 3.24.3", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "GATK", 
            "source": "https://software.broadinstitute.org/gatk/download/", 
            "version": "Version 3.8", 
            "usage": "SNP/Indel分析"
        }, 
        {
            "software_database": "WGCNA", 
            "source": "https://cran.r-project.org/web/packages/WGCNA/index.html", 
            "version": "Version 1.63", 
            "usage": "WGCNA分析"
        }, 
        {
            "software_database": "STRING 数据库", 
            "source": "https://string-db.org/", 
            "version": "Version 11.5", 
            "usage": "靶基因蛋白互作网络"
        }, 
        {
            "software_database": "sva", 
            "source": "http://www.bioconductor.org/packages/release/bioc/html/sva.html", 
            "version": "Version 3.20.0", 
            "usage": "移除批次效应影响"
        }, 
        {
            "software_database": "kallisto", 
            "source": "https://pachterlab.github.io/kallisto/download", 
            "version": "Version 0.46.2", 
            "usage": "表达量分析"
        }, 
        {
            "software_database": "PlantTFDB", 
            "source": "http://planttfdb_v4.cbi.pku.edu.cn/", 
            "version": "Version 5.0", 
            "usage": "转录因子预测"
        }, 
        {
            "software_database": "fastx_toolkit", 
            "source": "http://hannonlab.cshl.edu/fastx_toolkit/", 
            "version": "Version 0.0.14", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "NOISeq", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/NOISeq.html", 
            "version": "Version 2.18.0", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "Salmon", 
            "source": "https://github.com/COMBINE-lab/salmon", 
            "version": "Version 1.3.0", 
            "usage": "表达量分析"
        }, 
        {
            "software_database": "cufflinks", 
            "source": "http://cole-trapnell-lab.github.io/cufflinks/", 
            "version": "Version 2.2.1", 
            "usage": "转录本组装"
        }, 
        {
            "software_database": "Blast2go", 
            "source": "https://www.blast2go.com/", 
            "version": "Version 2.5", 
            "usage": "GO注释"
        }, 
        {
            "software_database": "STEM", 
            "source": "http://www.cs.cmu.edu/~jernst/stem/", 
            "version": "Version 1.3.11", 
            "usage": "时序表达趋势分析"
        }, 
        {
            "software_database": "MSigDB 数据库", 
            "source": "http://software.broadinstitute.org/gsea/downloads.jsp", 
            "version": "Version 6.2", 
            "usage": "GSEA分析"
        }, 
        {
            "software_database": "star_fusion", 
            "source": "https://github.com/STAR-Fusion/STAR-Fusion/wiki", 
            "version": "Version 1.8.1", 
            "usage": "基因融合鉴定"
        }, 
        {
            "software_database": "Sickle", 
            "source": "https://github.com/najoshi/sickle", 
            "version": "--", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "KOBAS", 
            "source": "http://kobas.cbi.pku.edu.cn/download.php", 
            "version": "Version 2.1.1", 
            "usage": "功能注释分类（KEGG）"
        }, 
        {
            "software_database": "GSEA", 
            "source": "http://software.broadinstitute.org/gsea/index.jsp", 
            "version": "Version 4.3.2", 
            "usage": "GSEA分析"
        }, 
        {
            "software_database": "Ipath 数据库", 
            "source": "https://pathways.embl.de/", 
            "version": "Version 3", 
            "usage": "iPath代谢通路分析"
        }, 
        {
            "software_database": "stringtie", 
            "source": "https://ccb.jhu.edu/software/stringtie/", 
            "version": "Version 2.1.2", 
            "usage": "转录本组装"
        }, 
        {
            "software_database": "fastp", 
            "source": "https://github.com/OpenGene/fastp", 
            "version": "0.19.5", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "TopHat", 
            "source": "http://ccb.jhu.edu/software/tophat/index.shtml", 
            "version": "Version v2.1.1", 
            "usage": "序列比对分析"
        }, 
        {
            "software_database": "DEGSeq", 
            "source": "http://bioconductor.org/packages/stats/bioc/DEGSeq/", 
            "version": "Version 1.38.0", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "Bowtie2", 
            "source": "http://downloads.sourceforge.net/project/bowtie-bio/bowtie2/2.4.1", 
            "version": "Version 2.4.1", 
            "usage": "序列比对"
        }, 
        {
            "software_database": "Diamond", 
            "source": "https://github.com/bbuchfink/diamond", 
            "version": "Version 0.9.24", 
            "usage": "多类数据库注释比较分析等"
        }, 
        {
            "software_database": "RSEM", 
            "source": "http://deweylab.biostat.wisc.edu/rsem/", 
            "version": "Version 1.3.3", 
            "usage": "表达量分析"
        }, 
        {
            "software_database": "ASprofile", 
            "source": "http://ccb.jhu.edu/software/ASprofile/", 
            "version": "Version 1.0", 
            "usage": "可变剪切分析"
        }, 
        {
            "software_database": "hisat2", 
            "source": "http://ccb.jhu.edu/software/hisat2/index.shtml", 
            "version": "Version 2.1.0", 
            "usage": "序列比对分析"
        }, 
        {
            "software_database": "JASPAR", 
            "source": "http://jaspar.genereg.net/", 
            "version": "Version 2020", 
            "usage": "转录因子预测"
        }, 
        {
            "software_database": "samtools", 
            "source": "https://github.com/samtools/samtools.git ", 
            "version": "Version 1.9", 
            "usage": "SNP/Indel分析"
        }, 
        {
            "software_database": "Limma", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/limma.html", 
            "version": "Version 3.38.3", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "HMMER", 
            "source": "ftp://selab.janelia.org/pub/software/hmmer3/3.0/hmmer-3.0.tar.gz", 
            "version": "Version 3.2.1", 
            "usage": "功能注释"
        }, 
        {
            "software_database": "DESeq2", 
            "source": "http://bioconductor.org/packages/stats/bioc/DESeq2/", 
            "version": "Version 1.24.0", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "BLAST+", 
            "source": "ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/2.9.0/", 
            "version": "Version 2.9.0", 
            "usage": "多类数据库注释比较分析等"
        }, 
        {
            "software_database": "bedtools", 
            "source": "https://bedtools.readthedocs.io/en/latest/", 
            "version": "Version 2.27.1", 
            "usage": "序列提取"
        }, 
        {
            "software_database": "goatools", 
            "source": "https://files.pythonhosted.org/packages/bb/7b/0c76e3511a79879606672e0741095a891dfb98cd63b1530ed8c51d406cda/goatools-0.8.9.tar.gz", 
            "version": "Version 0.6.5", 
            "usage": "基因集分析（GO富集）"
        }, 
        {
            "software_database": "maSigPro", 
            "source": "http://www.bioconductor.org/packages/release/bioc/html/maSigPro.html", 
            "version": "Version 1.56.0", 
            "usage": "时序差异聚类"
        }, 
        {
            "software_database": "AnimalTFDB", 
            "source": "http://bioinfo.life.hust.edu.cn/AnimalTFDB/#!/", 
            "version": "Version 3.0", 
            "usage": "转录因子预测"
        }, 
        {
            "software_database": "STAR", 
            "source": "http://code.google.com/p/rna-star/", 
            "version": "Version 2.7.1a", 
            "usage": "序列比对分析"
        }, 
        {
            "software_database": "Mfuzz", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
            "version": "Version 2.6.0", 
            "usage": "Mfuzz时序分析"
        }, 
        {
            "software_database": "Pfam 数据库", 
            "source": "http://pfam.xfam.org/", 
            "version": "Version 35.0", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "KEGG 数据库", 
            "source": "http://www.genome.jp/kegg/", 
            "version": "Version 2022.10", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "eggNOG 数据库", 
            "source": "http://eggnogdb.embl.de/#/app/home", 
            "version": "Version 2020.06", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "Rfam 数据库", 
            "source": "http://rfam.janelia.org/", 
            "version": "Version 14.8", 
            "usage": "核糖体比例评估"
        }, 
        {
            "software_database": "Swiss-prot 数据库", 
            "source": "ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz", 
            "version": "Version 2022.10", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "GO 数据库", 
            "source": "http://www.geneontology.org/", 
            "version": "Version 2022.0915", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "NR 数据库", 
            "source": "https://www.ncbi.nlm.nih.gov/public/", 
            "version": "Version 2022.10", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "Mfuzz", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
            "version": "Version 2.6.0", 
            "usage": "Mfuzz时序分析"
        }
    ], 
    "genesets": [
        "HS_vs_LS_G"
    ], 
    "user_info": {
        "sale_mail": "yuanyuan.yue@majorbio.com", 
        "group_name": "韩雨哲老师", 
        "sale_phone": "18516656225", 
        "project_mail": "17685270905@163.com", 
        "project_type": "有参转录组结题报告", 
        "primer_info": "组织样品", 
        "group_phone": "17685270905", 
        "fx_id": 259666, 
        "group_mail": "17685270905@163.com", 
        "sale_name": "岳媛媛", 
        "project_delivery_ts": "Novaseq", 
        "end_ts": "0000-00-00", 
        "sale_id": 10847, 
        "created_by": "rna", 
        "tech_support_mail": "rna@majorbio.com", 
        "company_name": "大连海洋大学", 
        "contract_sn": "MJ20240103447", 
        "sequencing_platform": "Novaseq", 
        "tech_support_name": "顾义平", 
        "start_ts": "0000-00-00", 
        "update_ts": "2024-01-26 15:07:02", 
        "project_people": "陈毅", 
        "address": "辽宁省大连市", 
        "tech_support_phone": "021-20725055", 
        "contract_id": 245689, 
        "customer": "陈毅", 
        "is_default": 0, 
        "created_ts": "2024-01-26 15:07:02", 
        "is_deleted": 0, 
        "project_phone": "17685270905", 
        "project_contract_id": 212257, 
        "created_id": 8955, 
        "project_sn": "h60a4tcjbh1t5htv0kr1b170od", 
        "source_origin": "日本囊对虾"
    }, 
    "samples": [
        "HS_1", 
        "HS_2", 
        "HS_3", 
        "LS_1", 
        "LS_2", 
        "LS_3"
    ], 
    "cmp_list": [
        [
            "HS", 
            "LS"
        ]
    ], 
    "table": {
        "table_5663": {
            "table_header": [
                {
                    "field": "Sample", 
                    "label": "Sample"
                }, 
                {
                    "field": "CDS", 
                    "label": "CDS"
                }, 
                {
                    "field": "5'UTR", 
                    "label": "5'UTR"
                }, 
                {
                    "field": "3'UTR", 
                    "label": "3'UTR"
                }, 
                {
                    "field": "Introns", 
                    "label": "Introns"
                }, 
                {
                    "field": "Intergenic", 
                    "label": "Intergenic"
                }
            ], 
            "table": [
                {
                    "Introns": "878880.0(1.96%)", 
                    "Intergenic": "1594052.0(3.55%)", 
                    "Sample": "HS_1", 
                    "CDS": "31867809.0(71.05%)", 
                    "3'UTR": "8000261.0(17.84%)", 
                    "5'UTR": "2514201.0(5.61%)"
                }, 
                {
                    "Introns": "716242.0(1.55%)", 
                    "Intergenic": "1221923.0(2.65%)", 
                    "Sample": "HS_2", 
                    "CDS": "34905958.0(75.59%)", 
                    "3'UTR": "6481748.0(14.04%)", 
                    "5'UTR": "2852322.0(6.18%)"
                }, 
                {
                    "Introns": "322404.0(0.74%)", 
                    "Intergenic": "876691.0(2.01%)", 
                    "Sample": "HS_3", 
                    "CDS": "34961812.0(80.2%)", 
                    "3'UTR": "4521313.0(10.37%)", 
                    "5'UTR": "2908513.0(6.67%)"
                }, 
                {
                    "Introns": "676254.0(1.69%)", 
                    "Intergenic": "2011665.0(5.02%)", 
                    "Sample": "LS_1", 
                    "CDS": "26613830.0(66.47%)", 
                    "3'UTR": "8961731.0(22.38%)", 
                    "5'UTR": "1776817.0(4.44%)"
                }, 
                {
                    "Introns": "605831.0(1.62%)", 
                    "Intergenic": "1899839.0(5.08%)", 
                    "Sample": "LS_2", 
                    "CDS": "24304507.0(65.0%)", 
                    "3'UTR": "8811359.0(23.56%)", 
                    "5'UTR": "1771745.0(4.74%)"
                }, 
                {
                    "Introns": "974151.0(2.11%)", 
                    "Intergenic": "2150931.0(4.67%)", 
                    "Sample": "LS_3", 
                    "CDS": "31136617.0(67.58%)", 
                    "3'UTR": "9491747.0(20.6%)", 
                    "5'UTR": "2318198.0(5.03%)"
                }
            ]
        }, 
        "table_5523": {
            "table_header": [
                {
                    "field": "SAMPLE", 
                    "label": "SAMPLE"
                }, 
                {
                    "field": "A3SS", 
                    "label": "A3SS"
                }, 
                {
                    "field": "A5SS", 
                    "label": "A5SS"
                }, 
                {
                    "field": "MXE", 
                    "label": "MXE"
                }, 
                {
                    "field": "RI", 
                    "label": "RI"
                }, 
                {
                    "field": "SE", 
                    "label": "SE"
                }, 
                {
                    "field": "TOTAL", 
                    "label": "TOTAL"
                }
            ], 
            "table": [
                {
                    "TOTAL": 11387, 
                    "A5SS": 1150, 
                    "SAMPLE": "HS_2", 
                    "SE": 6967, 
                    "MXE": 1238, 
                    "RI": 404, 
                    "A3SS": 1628
                }, 
                {
                    "TOTAL": 9691, 
                    "A5SS": 895, 
                    "SAMPLE": "HS_3", 
                    "SE": 6085, 
                    "MXE": 1086, 
                    "RI": 308, 
                    "A3SS": 1317
                }, 
                {
                    "TOTAL": 11994, 
                    "A5SS": 1218, 
                    "SAMPLE": "HS_1", 
                    "SE": 7288, 
                    "MXE": 1313, 
                    "RI": 447, 
                    "A3SS": 1728
                }, 
                {
                    "TOTAL": 9699, 
                    "A5SS": 927, 
                    "SAMPLE": "LS_2", 
                    "SE": 6128, 
                    "MXE": 994, 
                    "RI": 327, 
                    "A3SS": 1323
                }, 
                {
                    "TOTAL": 11146, 
                    "A5SS": 1115, 
                    "SAMPLE": "LS_3", 
                    "SE": 6870, 
                    "MXE": 1161, 
                    "RI": 377, 
                    "A3SS": 1623
                }, 
                {
                    "TOTAL": 9982, 
                    "A5SS": 941, 
                    "SAMPLE": "LS_1", 
                    "SE": 6321, 
                    "MXE": 1059, 
                    "RI": 323, 
                    "A3SS": 1338
                }
            ]
        }, 
        "table_5755": {
            "table_header": [
                {
                    "field": "Num", 
                    "label": "Num"
                }, 
                {
                    "field": "Description", 
                    "label": "Description"
                }, 
                {
                    "field": "Database", 
                    "label": "Database"
                }, 
                {
                    "field": "pathway_id", 
                    "label": "pathway_id"
                }, 
                {
                    "field": "Ratio_in_study", 
                    "label": "Ratio_in_study"
                }, 
                {
                    "field": "Ratio_in_pop", 
                    "label": "Ratio_in_pop"
                }, 
                {
                    "field": "P-Value", 
                    "label": "P-Value"
                }, 
                {
                    "field": "Corrected P-Value", 
                    "label": "Corrected P-Value"
                }, 
                {
                    "field": "Genes", 
                    "label": "Genes"
                }, 
                {
                    "field": "typeII", 
                    "label": "typeII"
                }, 
                {
                    "field": "typeI", 
                    "label": "typeI"
                }
            ], 
            "table": [
                {
                    "pathway_id": "map04964", 
                    "P-Value": 1.82710495505e-05, 
                    "Corrected P-Value": 0.0034532283650500002, 
                    "Description": "Proximal tubule bicarbonate reclamation", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122244877|gene-LOC122258680|gene-LOC122256189|gene-LOC122248528|gene-LOC122250651|gene-LOC122266655", 
                    "typeII": "Excretory system", 
                    "Ratio_in_study": "6/180", 
                    "Num": 6, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "40/12811"
                }, 
                {
                    "pathway_id": "map04972", 
                    "P-Value": 0.00013795443215, 
                    "Corrected P-Value": 0.013036693838200001, 
                    "Description": "Pancreatic secretion", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122255752|gene-LOC122258680|gene-LOC122244877|gene-LOC122260629|gene-LOC122256189|gene-LOC122264861|gene-LOC122248528|gene-LOC122262223|gene-LOC122266655|gene-LOC122266745|gene-LOC122246635", 
                    "typeII": "Digestive system", 
                    "Ratio_in_study": "11/180", 
                    "Num": 11, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "203/12811"
                }, 
                {
                    "pathway_id": "map05410", 
                    "P-Value": 0.0006092646117819999, 
                    "Corrected P-Value": 0.019191835271099997, 
                    "Description": "Hypertrophic cardiomyopathy", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122242521|gene-LOC122255752|gene-LOC122247484|gene-LOC122258618|gene-LOC122263446|gene-LOC122262949|gene-LOC122250387|gene-LOC122266745|gene-LOC122256104", 
                    "typeII": "Cardiovascular disease", 
                    "Ratio_in_study": "9/180", 
                    "Num": 9, 
                    "typeI": "Human Diseases", 
                    "Ratio_in_pop": "168/12811"
                }, 
                {
                    "pathway_id": "map00910", 
                    "P-Value": 0.000513735817926, 
                    "Corrected P-Value": 0.019419213917599997, 
                    "Description": "Nitrogen metabolism", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122266655|gene-LOC122256189|gene-LOC122244877|gene-LOC122258680", 
                    "typeII": "Energy metabolism", 
                    "Ratio_in_study": "4/180", 
                    "Num": 4, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "27/12811"
                }, 
                {
                    "pathway_id": "map05414", 
                    "P-Value": 0.000721546086493, 
                    "Corrected P-Value": 0.019481744335300002, 
                    "Description": "Dilated cardiomyopathy", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122242521|gene-LOC122255752|gene-LOC122247484|gene-LOC122258618|gene-LOC122263446|gene-LOC122262949|gene-LOC122250387|gene-LOC122266745|gene-LOC122256104", 
                    "typeII": "Cardiovascular disease", 
                    "Ratio_in_study": "9/180", 
                    "Num": 9, 
                    "typeI": "Human Diseases", 
                    "Ratio_in_pop": "172/12811"
                }, 
                {
                    "pathway_id": "map04966", 
                    "P-Value": 0.0008816204275599999, 
                    "Corrected P-Value": 0.0208282826011, 
                    "Description": "Collecting duct acid secretion", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122266655|gene-LOC122256189|gene-LOC122244877|gene-LOC122258680", 
                    "typeII": "Excretory system", 
                    "Ratio_in_study": "4/180", 
                    "Num": 4, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "31/12811"
                }, 
                {
                    "pathway_id": "map04974", 
                    "P-Value": 0.00045320702406999997, 
                    "Corrected P-Value": 0.0214140318873, 
                    "Description": "Protein digestion and absorption", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122253962|gene-LOC122262223|gene-LOC122253961|gene-LOC122255991|gene-LOC122255994|gene-LOC122265394|gene-LOC122258797|gene-LOC122264861|gene-LOC122248528|gene-LOC122246635|gene-LOC122256104", 
                    "typeII": "Digestive system", 
                    "Ratio_in_study": "11/180", 
                    "Num": 11, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "233/12811"
                }, 
                {
                    "pathway_id": "map05412", 
                    "P-Value": 0.00123599144276, 
                    "Corrected P-Value": 0.025955820298, 
                    "Description": "Arrhythmogenic right ventricular cardiomyopathy", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122242521|gene-LOC122255752|gene-LOC122247484|gene-LOC122258618|gene-LOC122266745|gene-LOC122256104", 
                    "typeII": "Cardiovascular disease", 
                    "Ratio_in_study": "6/180", 
                    "Num": 6, 
                    "typeI": "Human Diseases", 
                    "Ratio_in_pop": "85/12811"
                }, 
                {
                    "pathway_id": "map04260", 
                    "P-Value": 0.000420532484022, 
                    "Corrected P-Value": 0.0264935464934, 
                    "Description": "Cardiac muscle contraction", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122255752|gene-LOC122247484|gene-LOC122263446|gene-LOC122262949|gene-LOC122248528|gene-LOC122250387|gene-LOC122266745|gene-LOC122256104", 
                    "typeII": "Circulatory system", 
                    "Ratio_in_study": "8/180", 
                    "Num": 8, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "127/12811"
                }, 
                {
                    "pathway_id": "map04976", 
                    "P-Value": 0.00196454864367, 
                    "Corrected P-Value": 0.0309416411378, 
                    "Description": "Bile secretion", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC122244877|gene-LOC122258680|gene-LOC122256189|gene-LOC122248528|gene-LOC122268167|gene-LOC122266655", 
                    "typeII": "Digestive system", 
                    "Ratio_in_study": "6/180", 
                    "Num": 6, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "93/12811"
                }
            ]
        }, 
        "table_5665": {
            "table_header": [
                {
                    "field": "Chromosome", 
                    "label": "Chromosome"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "HS_2": 12708872, 
                    "HS_3": 16193636, 
                    "HS_1": 10009650, 
                    "LS_2": 15967399, 
                    "LS_3": 7536459, 
                    "LS_1": 12352817, 
                    "Chromosome": "NC_007010.1"
                }, 
                {
                    "HS_2": 506, 
                    "HS_3": 419, 
                    "HS_1": 580, 
                    "LS_2": 515, 
                    "LS_3": 1105, 
                    "LS_1": 414, 
                    "Chromosome": "NW_025029446.1"
                }, 
                {
                    "HS_2": 25576, 
                    "HS_3": 29824, 
                    "HS_1": 37504, 
                    "LS_2": 31509, 
                    "LS_3": 50913, 
                    "LS_1": 46563, 
                    "Chromosome": "NW_025029447.1"
                }, 
                {
                    "HS_2": 12235, 
                    "HS_3": 7096, 
                    "HS_1": 16824, 
                    "LS_2": 14706, 
                    "LS_3": 23551, 
                    "LS_1": 14318, 
                    "Chromosome": "NW_025029448.1"
                }, 
                {
                    "HS_2": 2810, 
                    "HS_3": 1229, 
                    "HS_1": 4464, 
                    "LS_2": 4187, 
                    "LS_3": 6790, 
                    "LS_1": 4025, 
                    "Chromosome": "NW_025029449.1"
                }, 
                {
                    "HS_2": 4314, 
                    "HS_3": 3007, 
                    "HS_1": 5163, 
                    "LS_2": 6619, 
                    "LS_3": 11398, 
                    "LS_1": 9031, 
                    "Chromosome": "NW_025029450.1"
                }, 
                {
                    "HS_2": 9031, 
                    "HS_3": 4896, 
                    "HS_1": 11125, 
                    "LS_2": 10676, 
                    "LS_3": 14647, 
                    "LS_1": 11570, 
                    "Chromosome": "NW_025029451.1"
                }, 
                {
                    "HS_2": 13202, 
                    "HS_3": 41025, 
                    "HS_1": 15023, 
                    "LS_2": 10641, 
                    "LS_3": 12810, 
                    "LS_1": 15520, 
                    "Chromosome": "NW_025029452.1"
                }, 
                {
                    "HS_2": 1903, 
                    "HS_3": 1471, 
                    "HS_1": 2126, 
                    "LS_2": 1632, 
                    "LS_3": 1665, 
                    "LS_1": 1547, 
                    "Chromosome": "NW_025029453.1"
                }, 
                {
                    "HS_2": 1379, 
                    "HS_3": 592, 
                    "HS_1": 2723, 
                    "LS_2": 2938, 
                    "LS_3": 7998, 
                    "LS_1": 2420, 
                    "Chromosome": "NW_025029454.1"
                }, 
                {
                    "HS_2": 3741, 
                    "HS_3": 3815, 
                    "HS_1": 4747, 
                    "LS_2": 4420, 
                    "LS_3": 6986, 
                    "LS_1": 5205, 
                    "Chromosome": "NW_025029455.1"
                }, 
                {
                    "HS_2": 5436, 
                    "HS_3": 3268, 
                    "HS_1": 7827, 
                    "LS_2": 6150, 
                    "LS_3": 10760, 
                    "LS_1": 6517, 
                    "Chromosome": "NW_025029456.1"
                }, 
                {
                    "HS_2": 5467, 
                    "HS_3": 2605, 
                    "HS_1": 8220, 
                    "LS_2": 7900, 
                    "LS_3": 12375, 
                    "LS_1": 9737, 
                    "Chromosome": "NW_025029457.1"
                }, 
                {
                    "HS_2": 61054, 
                    "HS_3": 9591, 
                    "HS_1": 149736, 
                    "LS_2": 155595, 
                    "LS_3": 248896, 
                    "LS_1": 140293, 
                    "Chromosome": "NW_025029458.1"
                }, 
                {
                    "HS_2": 260, 
                    "HS_3": 156, 
                    "HS_1": 389, 
                    "LS_2": 282, 
                    "LS_3": 691, 
                    "LS_1": 322, 
                    "Chromosome": "NW_025029459.1"
                }, 
                {
                    "HS_2": 224, 
                    "HS_3": 56, 
                    "HS_1": 550, 
                    "LS_2": 343, 
                    "LS_3": 726, 
                    "LS_1": 357, 
                    "Chromosome": "NW_025029460.1"
                }, 
                {
                    "HS_2": 14342, 
                    "HS_3": 7316, 
                    "HS_1": 23746, 
                    "LS_2": 20492, 
                    "LS_3": 30182, 
                    "LS_1": 21457, 
                    "Chromosome": "NW_025029461.1"
                }, 
                {
                    "HS_2": 144, 
                    "HS_3": 145, 
                    "HS_1": 573, 
                    "LS_2": 361, 
                    "LS_3": 882, 
                    "LS_1": 549, 
                    "Chromosome": "NW_025029462.1"
                }, 
                {
                    "HS_2": 2487, 
                    "HS_3": 916, 
                    "HS_1": 4554, 
                    "LS_2": 4189, 
                    "LS_3": 5857, 
                    "LS_1": 4670, 
                    "Chromosome": "NW_025029463.1"
                }, 
                {
                    "HS_2": 20854, 
                    "HS_3": 10506, 
                    "HS_1": 23966, 
                    "LS_2": 23250, 
                    "LS_3": 26628, 
                    "LS_1": 23604, 
                    "Chromosome": "NW_025029464.1"
                }, 
                {
                    "HS_2": 6915, 
                    "HS_3": 5224, 
                    "HS_1": 11259, 
                    "LS_2": 8091, 
                    "LS_3": 15152, 
                    "LS_1": 8244, 
                    "Chromosome": "NW_025029465.1"
                }, 
                {
                    "HS_2": 5376, 
                    "HS_3": 5385, 
                    "HS_1": 10191, 
                    "LS_2": 6880, 
                    "LS_3": 14376, 
                    "LS_1": 7150, 
                    "Chromosome": "NW_025029466.1"
                }, 
                {
                    "HS_2": 197869, 
                    "HS_3": 81529, 
                    "HS_1": 143129, 
                    "LS_2": 181475, 
                    "LS_3": 202808, 
                    "LS_1": 159134, 
                    "Chromosome": "NW_025029467.1"
                }, 
                {
                    "HS_2": 24154, 
                    "HS_3": 8811, 
                    "HS_1": 27278, 
                    "LS_2": 29914, 
                    "LS_3": 33434, 
                    "LS_1": 37306, 
                    "Chromosome": "NW_025029468.1"
                }, 
                {
                    "HS_2": 2570, 
                    "HS_3": 1352, 
                    "HS_1": 4609, 
                    "LS_2": 3219, 
                    "LS_3": 5875, 
                    "LS_1": 2627, 
                    "Chromosome": "NW_025029469.1"
                }, 
                {
                    "HS_2": 6463, 
                    "HS_3": 2255, 
                    "HS_1": 11258, 
                    "LS_2": 9117, 
                    "LS_3": 20975, 
                    "LS_1": 12371, 
                    "Chromosome": "NW_025029470.1"
                }, 
                {
                    "HS_2": 37597, 
                    "HS_3": 24689, 
                    "HS_1": 30115, 
                    "LS_2": 29272, 
                    "LS_3": 40478, 
                    "LS_1": 32340, 
                    "Chromosome": "NW_025029471.1"
                }, 
                {
                    "HS_2": 14419, 
                    "HS_3": 9597, 
                    "HS_1": 17495, 
                    "LS_2": 18189, 
                    "LS_3": 22866, 
                    "LS_1": 22197, 
                    "Chromosome": "NW_025029472.1"
                }, 
                {
                    "HS_2": 18651, 
                    "HS_3": 9156, 
                    "HS_1": 25012, 
                    "LS_2": 21654, 
                    "LS_3": 41103, 
                    "LS_1": 23209, 
                    "Chromosome": "NW_025029473.1"
                }, 
                {
                    "HS_2": 3440, 
                    "HS_3": 1757, 
                    "HS_1": 6489, 
                    "LS_2": 5636, 
                    "LS_3": 10925, 
                    "LS_1": 7294, 
                    "Chromosome": "NW_025029474.1"
                }, 
                {
                    "HS_2": 1866, 
                    "HS_3": 1128, 
                    "HS_1": 2968, 
                    "LS_2": 2089, 
                    "LS_3": 3391, 
                    "LS_1": 1696, 
                    "Chromosome": "NW_025029475.1"
                }, 
                {
                    "HS_2": 1380, 
                    "HS_3": 586, 
                    "HS_1": 3070, 
                    "LS_2": 1753, 
                    "LS_3": 3520, 
                    "LS_1": 2360, 
                    "Chromosome": "NW_025029476.1"
                }, 
                {
                    "HS_2": 10098, 
                    "HS_3": 4613, 
                    "HS_1": 13167, 
                    "LS_2": 1590, 
                    "LS_3": 6399, 
                    "LS_1": 1441, 
                    "Chromosome": "NW_025029477.1"
                }, 
                {
                    "HS_2": 2132, 
                    "HS_3": 924, 
                    "HS_1": 2852, 
                    "LS_2": 1693, 
                    "LS_3": 4393, 
                    "LS_1": 1828, 
                    "Chromosome": "NW_025029478.1"
                }, 
                {
                    "HS_2": 64964, 
                    "HS_3": 48082, 
                    "HS_1": 64558, 
                    "LS_2": 56802, 
                    "LS_3": 61766, 
                    "LS_1": 58990, 
                    "Chromosome": "NW_025029479.1"
                }, 
                {
                    "HS_2": 580, 
                    "HS_3": 353, 
                    "HS_1": 1592, 
                    "LS_2": 905, 
                    "LS_3": 2317, 
                    "LS_1": 731, 
                    "Chromosome": "NW_025029480.1"
                }, 
                {
                    "HS_2": 1026, 
                    "HS_3": 591, 
                    "HS_1": 1427, 
                    "LS_2": 929, 
                    "LS_3": 2153, 
                    "LS_1": 2079, 
                    "Chromosome": "NW_025029481.1"
                }, 
                {
                    "HS_2": 15915, 
                    "HS_3": 9072, 
                    "HS_1": 20016, 
                    "LS_2": 16028, 
                    "LS_3": 21580, 
                    "LS_1": 15214, 
                    "Chromosome": "NW_025029482.1"
                }, 
                {
                    "HS_2": 12980, 
                    "HS_3": 8546, 
                    "HS_1": 18470, 
                    "LS_2": 11722, 
                    "LS_3": 26573, 
                    "LS_1": 19845, 
                    "Chromosome": "NW_025029483.1"
                }, 
                {
                    "HS_2": 1601, 
                    "HS_3": 1080, 
                    "HS_1": 2176, 
                    "LS_2": 1621, 
                    "LS_3": 2216, 
                    "LS_1": 1797, 
                    "Chromosome": "NW_025029484.1"
                }, 
                {
                    "HS_2": 6525, 
                    "HS_3": 2880, 
                    "HS_1": 9256, 
                    "LS_2": 7701, 
                    "LS_3": 13458, 
                    "LS_1": 7853, 
                    "Chromosome": "NW_025029485.1"
                }, 
                {
                    "HS_2": 21427, 
                    "HS_3": 7759, 
                    "HS_1": 28815, 
                    "LS_2": 32622, 
                    "LS_3": 38852, 
                    "LS_1": 32913, 
                    "Chromosome": "NW_025029486.1"
                }, 
                {
                    "HS_2": 9249, 
                    "HS_3": 3816, 
                    "HS_1": 14539, 
                    "LS_2": 11849, 
                    "LS_3": 22020, 
                    "LS_1": 11645, 
                    "Chromosome": "NW_025029487.1"
                }, 
                {
                    "HS_2": 671, 
                    "HS_3": 347, 
                    "HS_1": 1237, 
                    "LS_2": 1001, 
                    "LS_3": 1485, 
                    "LS_1": 1212, 
                    "Chromosome": "NW_025029488.1"
                }, 
                {
                    "HS_2": 517, 
                    "HS_3": 763, 
                    "HS_1": 524, 
                    "LS_2": 911, 
                    "LS_3": 1568, 
                    "LS_1": 584, 
                    "Chromosome": "NW_025029489.1"
                }, 
                {
                    "HS_2": 7722, 
                    "HS_3": 4483, 
                    "HS_1": 13963, 
                    "LS_2": 10474, 
                    "LS_3": 20122, 
                    "LS_1": 12278, 
                    "Chromosome": "NW_025029490.1"
                }, 
                {
                    "HS_2": 5055, 
                    "HS_3": 1870, 
                    "HS_1": 10577, 
                    "LS_2": 7152, 
                    "LS_3": 16819, 
                    "LS_1": 8197, 
                    "Chromosome": "NW_025029491.1"
                }, 
                {
                    "HS_2": 3294, 
                    "HS_3": 3374, 
                    "HS_1": 4378, 
                    "LS_2": 2248, 
                    "LS_3": 1660, 
                    "LS_1": 1997, 
                    "Chromosome": "NW_025029492.1"
                }, 
                {
                    "HS_2": 18855, 
                    "HS_3": 12677, 
                    "HS_1": 24851, 
                    "LS_2": 21048, 
                    "LS_3": 28012, 
                    "LS_1": 35753, 
                    "Chromosome": "NW_025029493.1"
                }, 
                {
                    "HS_2": 4666, 
                    "HS_3": 2788, 
                    "HS_1": 6407, 
                    "LS_2": 5029, 
                    "LS_3": 6695, 
                    "LS_1": 4314, 
                    "Chromosome": "NW_025029494.1"
                }
            ]
        }, 
        "table_5871": {
            "table_header": [
                {
                    "field": "Type", 
                    "label": "Type"
                }, 
                {
                    "field": "Functional Categoris", 
                    "label": "Functional Categoris"
                }, 
                {
                    "field": "HS_vs_LS_G_COG", 
                    "label": "HS_vs_LS_G_COG"
                }, 
                {
                    "field": "HS_vs_LS_G_COG_list", 
                    "label": "HS_vs_LS_G_COG_list"
                }
            ], 
            "table": [
                {
                    "Functional Categoris": "[B] Chromatin structure and dynamics", 
                    "Type": "INFORMATION STORAGE AND PROCESSING", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122246545", 
                    "HS_vs_LS_G_COG": 1
                }, 
                {
                    "Functional Categoris": "[D] Cell cycle control, cell division, chromosome partitioning", 
                    "Type": "CELLULAR PROCESSES AND SIGNALING", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122252392;gene-LOC122260438;gene-LOC122255518", 
                    "HS_vs_LS_G_COG": 3
                }, 
                {
                    "Functional Categoris": "[E] Amino acid transport and metabolism", 
                    "Type": "METABOLISM", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122263489;gene-LOC122256701;gene-LOC122252247;gene-LOC122259681;gene-LOC122243412;gene-LOC122250651;gene-LOC122266931;gene-LOC122254329", 
                    "HS_vs_LS_G_COG": 8
                }, 
                {
                    "Functional Categoris": "[F] Nucleotide transport and metabolism", 
                    "Type": "METABOLISM", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122255789;gene-LOC122251692;gene-LOC122247243;gene-LOC122260966", 
                    "HS_vs_LS_G_COG": 4
                }, 
                {
                    "Functional Categoris": "[G] Carbohydrate transport and metabolism", 
                    "Type": "METABOLISM", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122260510;gene-LOC122260221;gene-LOC122261982;gene-LOC122254107;gene-LOC122251240;gene-LOC122258788;gene-LOC122257102;gene-LOC122260629;gene-LOC122257108;gene-LOC122242249;gene-LOC122250540;gene-LOC122263421;gene-LOC122251129;gene-LOC122253843;gene-LOC122246980", 
                    "HS_vs_LS_G_COG": 15
                }, 
                {
                    "Functional Categoris": "[H] Coenzyme transport and metabolism", 
                    "Type": "METABOLISM", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122247127", 
                    "HS_vs_LS_G_COG": 1
                }, 
                {
                    "Functional Categoris": "[I] Lipid transport and metabolism", 
                    "Type": "METABOLISM", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122247694;gene-LOC122259512;gene-LOC122264467;gene-LOC122250809;gene-LOC122260125;gene-LOC122257811;gene-LOC122244707;gene-LOC122255240;gene-LOC122244708;gene-LOC122253432", 
                    "HS_vs_LS_G_COG": 10
                }, 
                {
                    "Functional Categoris": "[K] Transcription", 
                    "Type": "INFORMATION STORAGE AND PROCESSING", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122259561;gene-LOC122256536;gene-LOC122256128;gene-LOC122266860;gene-LOC122246973;gene-LOC122248629;gene-LOC122247211;gene-LOC122262447;gene-LOC122267098;gene-LOC122264670;gene-LOC122253122", 
                    "HS_vs_LS_G_COG": 11
                }, 
                {
                    "Functional Categoris": "[L] Replication, recombination and repair", 
                    "Type": "INFORMATION STORAGE AND PROCESSING", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122247173;gene-LOC122261899", 
                    "HS_vs_LS_G_COG": 2
                }, 
                {
                    "Functional Categoris": "[M] Cell wall/membrane/envelope biogenesis", 
                    "Type": "CELLULAR PROCESSES AND SIGNALING", 
                    "HS_vs_LS_G_COG_list": "gene-LOC122251241", 
                    "HS_vs_LS_G_COG": 1
                }
            ]
        }, 
        "table_5685": {
            "table_header": [
                {
                    "field": "sample", 
                    "label": "sample"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "HS_2": 0.937844328617, 
                    "HS_3": 0.8495534047490001, 
                    "HS_1": 1.0, 
                    "sample": "HS_1", 
                    "LS_2": 0.912894457365, 
                    "LS_3": 0.8729093273649999, 
                    "LS_1": 0.908832334348
                }, 
                {
                    "HS_2": 1.0, 
                    "HS_3": 0.9315966785609999, 
                    "HS_1": 0.937844328617, 
                    "sample": "HS_2", 
                    "LS_2": 0.879889922714, 
                    "LS_3": 0.785429288407, 
                    "LS_1": 0.8751598581059999
                }, 
                {
                    "HS_2": 0.9315966785609999, 
                    "HS_3": 1.0, 
                    "HS_1": 0.8495534047490001, 
                    "sample": "HS_3", 
                    "LS_2": 0.80584167682, 
                    "LS_3": 0.7210004561910001, 
                    "LS_1": 0.832343075675
                }, 
                {
                    "HS_2": 0.8751598581059999, 
                    "HS_3": 0.832343075675, 
                    "HS_1": 0.908832334348, 
                    "sample": "LS_1", 
                    "LS_2": 0.945618320253, 
                    "LS_3": 0.927405629794, 
                    "LS_1": 1.0
                }, 
                {
                    "HS_2": 0.879889922714, 
                    "HS_3": 0.80584167682, 
                    "HS_1": 0.912894457365, 
                    "sample": "LS_2", 
                    "LS_2": 1.0, 
                    "LS_3": 0.935463724606, 
                    "LS_1": 0.945618320253
                }, 
                {
                    "HS_2": 0.785429288407, 
                    "HS_3": 0.7210004561910001, 
                    "HS_1": 0.8729093273649999, 
                    "sample": "LS_3", 
                    "LS_2": 0.935463724606, 
                    "LS_3": 1.0, 
                    "LS_1": 0.927405629794
                }
            ]
        }, 
        "table_5687": {
            "table_header": [
                {
                    "field": "PC", 
                    "label": "PC"
                }, 
                {
                    "field": "Proportion of Variance", 
                    "label": "Proportion of Variance"
                }
            ], 
            "table": [
                {
                    "PC": "PC1", 
                    "Proportion of Variance": 0.585290078107
                }, 
                {
                    "PC": "PC2", 
                    "Proportion of Variance": 0.184380851091
                }, 
                {
                    "PC": "PC3", 
                    "Proportion of Variance": 0.107298750155
                }, 
                {
                    "PC": "PC4", 
                    "Proportion of Variance": 0.07722861454360001
                }
            ]
        }, 
        "table_5719": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "HS_2": 0.968403164408, 
                    "HS_3": 0.192812405611, 
                    "HS_1": 1.5509931040399998, 
                    "LS_3": -0.6064821793940001, 
                    "LS_2": -1.18434786529, 
                    "Gene id": "gene-LOC122265874", 
                    "LS_1": -0.921378629383
                }, 
                {
                    "HS_2": 0.968403164408, 
                    "HS_3": 0.192812405611, 
                    "HS_1": 1.5509931040399998, 
                    "LS_3": -0.6064821793940001, 
                    "LS_2": -1.18434786529, 
                    "Gene id": "gene-LOC122259669", 
                    "LS_1": -0.921378629383
                }, 
                {
                    "HS_2": 0.9404225962780001, 
                    "HS_3": 0.40026670975199996, 
                    "HS_1": 1.31409344016, 
                    "LS_3": -0.146626725508, 
                    "LS_2": -1.4296166433200002, 
                    "Gene id": "gene-LOC122256691", 
                    "LS_1": -1.07853937736
                }, 
                {
                    "HS_2": 0.55486649655, 
                    "HS_3": 0.6151274797190001, 
                    "HS_1": 1.53798658396, 
                    "LS_3": -0.328055782528, 
                    "LS_2": -1.2559057434799998, 
                    "Gene id": "gene-LOC122260788", 
                    "LS_1": -1.1240190342299998
                }, 
                {
                    "HS_2": 1.3057526560200001, 
                    "HS_3": 0.189245084638, 
                    "HS_1": 1.27241286653, 
                    "LS_3": -1.16098600691, 
                    "LS_2": -0.834623205045, 
                    "Gene id": "gene-LOC122267744", 
                    "LS_1": -0.771801395231
                }, 
                {
                    "HS_2": -0.8652112973649999, 
                    "HS_3": -1.15556222285, 
                    "HS_1": -0.889258337943, 
                    "LS_3": 1.4103676658700002, 
                    "LS_2": 0.8262247353919999, 
                    "Gene id": "gene-LOC122264964", 
                    "LS_1": 0.673439456896
                }, 
                {
                    "HS_2": -1.00465319592, 
                    "HS_3": -1.2862093649700002, 
                    "HS_1": -0.521881335016, 
                    "LS_3": 1.4074151019, 
                    "LS_2": 0.483934519216, 
                    "Gene id": "gene-LOC122264383", 
                    "LS_1": 0.9213942747939999
                }, 
                {
                    "HS_2": 1.30458485198, 
                    "HS_3": 0.688915119913, 
                    "HS_1": 0.8296893688420001, 
                    "LS_3": -0.40345568503300006, 
                    "LS_2": -1.06030429795, 
                    "Gene id": "gene-LOC122253056", 
                    "LS_1": -1.35942935775
                }, 
                {
                    "HS_2": -0.913408302727, 
                    "HS_3": -1.28915014127, 
                    "HS_1": -0.586176134313, 
                    "LS_3": 1.54457546311, 
                    "LS_2": 0.637818238266, 
                    "Gene id": "gene-LOC122249527", 
                    "LS_1": 0.606340876932
                }, 
                {
                    "HS_2": 0.354997482352, 
                    "HS_3": 0.14013479095200002, 
                    "HS_1": 1.8673508816599997, 
                    "LS_3": -0.21479338304200002, 
                    "LS_2": -1.16020991669, 
                    "Gene id": "gene-LOC122250809", 
                    "LS_1": -0.987479855229
                }
            ]
        }, 
        "table_9813": {
            "table_header": [
                {
                    "field": "AS type", 
                    "label": "AS type"
                }, 
                {
                    "field": "Exclusion (Increase exclusion in case，ΔPSI<0)", 
                    "label": "Exclusion (Increase exclusion in case，ΔPSI<0)"
                }, 
                {
                    "field": "Inclusion (Increase inclusion in case, ΔPSI>0)", 
                    "label": "Inclusion (Increase inclusion in case, ΔPSI>0)"
                }, 
                {
                    "field": "Total events", 
                    "label": "Total events"
                }
            ], 
            "table": [
                {
                    "Total events": 338, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 137, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 201, 
                    "AS type": "SE"
                }, 
                {
                    "Total events": 144, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 81, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 63, 
                    "AS type": "MXE"
                }, 
                {
                    "Total events": 61, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 32, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 29, 
                    "AS type": "A3SS"
                }, 
                {
                    "Total events": 71, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 29, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 42, 
                    "AS type": "A5SS"
                }, 
                {
                    "Total events": 52, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 36, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 16, 
                    "AS type": "RI"
                }, 
                {
                    "Total events": 666, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 315, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 351, 
                    "AS type": "TOTAL"
                }
            ]
        }, 
        "table_9812": {
            "table_header": [
                {
                    "field": "AS type", 
                    "label": "AS type"
                }, 
                {
                    "field": "JunctionCountOnly(JC)", 
                    "label": "JunctionCountOnly(JC)"
                }, 
                {
                    "field": "ReadsOnTargetAndJunctionCounts(JCEC)", 
                    "label": "ReadsOnTargetAndJunctionCounts(JCEC)"
                }, 
                {
                    "field": "JC&JCEC", 
                    "label": "JC&JCEC"
                }, 
                {
                    "field": "JC|JCEC", 
                    "label": "JC|JCEC"
                }
            ], 
            "table": [
                {
                    "JunctionCountOnly(JC)": 338, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 337, 
                    "JC&JCEC": 330, 
                    "JC|JCEC": 345, 
                    "AS type": "SE"
                }, 
                {
                    "JunctionCountOnly(JC)": 144, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 145, 
                    "JC&JCEC": 142, 
                    "JC|JCEC": 147, 
                    "AS type": "MXE"
                }, 
                {
                    "JunctionCountOnly(JC)": 61, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 64, 
                    "JC&JCEC": 60, 
                    "JC|JCEC": 65, 
                    "AS type": "A3SS"
                }, 
                {
                    "JunctionCountOnly(JC)": 71, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 74, 
                    "JC&JCEC": 71, 
                    "JC|JCEC": 74, 
                    "AS type": "A5SS"
                }, 
                {
                    "JunctionCountOnly(JC)": 52, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 50, 
                    "JC&JCEC": 48, 
                    "JC|JCEC": 54, 
                    "AS type": "RI"
                }, 
                {
                    "JunctionCountOnly(JC)": 666, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 670, 
                    "JC&JCEC": 651, 
                    "JC|JCEC": 685, 
                    "AS type": "TOTAL"
                }
            ]
        }, 
        "table_5677": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "Gene name", 
                    "label": "Gene name"
                }, 
                {
                    "field": "Gene description", 
                    "label": "Gene description"
                }, 
                {
                    "field": "length", 
                    "label": "length"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }, 
                {
                    "field": "HS", 
                    "label": "HS"
                }, 
                {
                    "field": "LS", 
                    "label": "LS"
                }, 
                {
                    "field": "nr", 
                    "label": "nr"
                }, 
                {
                    "field": "go", 
                    "label": "go"
                }, 
                {
                    "field": "KO_id", 
                    "label": "KO_id"
                }, 
                {
                    "field": "KO_name", 
                    "label": "KO_name"
                }, 
                {
                    "field": "paths", 
                    "label": "paths"
                }, 
                {
                    "field": "cog", 
                    "label": "cog"
                }, 
                {
                    "field": "cog_description", 
                    "label": "cog_description"
                }, 
                {
                    "field": "pfam", 
                    "label": "pfam"
                }, 
                {
                    "field": "swissprot", 
                    "label": "swissprot"
                }, 
                {
                    "field": "entrez", 
                    "label": "entrez"
                }
            ], 
            "table": [
                {
                    "cog_description": "", 
                    "HS": 75.4533, 
                    "HS_2": 81.25, 
                    "HS_3": 41.11, 
                    "HS_1": 104.0, 
                    "LS_2": 249.44, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 230.64, 
                    "LS_1": 322.49, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 267.5233, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 4440, 
                    "cog": "", 
                    "Gene id": "MSTRG.10005", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 44.7167, 
                    "HS_2": 35.0, 
                    "HS_3": 14.09, 
                    "HS_1": 85.06, 
                    "LS_2": 145.03, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 120.0, 
                    "LS_1": 123.45, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 129.4933, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 2047, 
                    "cog": "", 
                    "Gene id": "MSTRG.10006", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 41.6667, 
                    "HS_2": 47.0, 
                    "HS_3": 47.0, 
                    "HS_1": 31.0, 
                    "LS_2": 97.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 53.0, 
                    "LS_1": 128.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 92.6667, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 788, 
                    "cog": "", 
                    "Gene id": "MSTRG.10009", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 9.6667, 
                    "HS_2": 8.0, 
                    "HS_3": 6.0, 
                    "HS_1": 15.0, 
                    "LS_2": 9.0, 
                    "Gene name": "", 
                    "go": "GO:0016020(cellular_component:membrane); GO:0008083(molecular_function:growth factor activity)", 
                    "LS_3": 7.0, 
                    "LS_1": 9.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 8.3333, 
                    "Gene description": "", 
                    "nr": "KAG7155465.1(putative PDGF/VEGF domain-containing protein 4 [Homarus americanus])", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 686, 
                    "cog": "", 
                    "Gene id": "MSTRG.10019", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 18.6667, 
                    "HS_2": 21.0, 
                    "HS_3": 15.0, 
                    "HS_1": 20.0, 
                    "LS_2": 33.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 20.0, 
                    "LS_1": 44.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 32.3333, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 789, 
                    "cog": "", 
                    "Gene id": "MSTRG.10043", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 4.2967, 
                    "HS_2": 4.0, 
                    "HS_3": 3.89, 
                    "HS_1": 5.0, 
                    "LS_2": 8.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 6.0, 
                    "LS_1": 0.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 4.6667, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 396, 
                    "cog": "", 
                    "Gene id": "MSTRG.10046", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 46.6667, 
                    "HS_2": 51.0, 
                    "HS_3": 35.0, 
                    "HS_1": 54.0, 
                    "LS_2": 100.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 52.0, 
                    "LS_1": 73.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 75.0, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 1337, 
                    "cog": "", 
                    "Gene id": "MSTRG.10059", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 213.6667, 
                    "HS_2": 292.0, 
                    "HS_3": 73.0, 
                    "HS_1": 276.0, 
                    "LS_2": 470.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 395.0, 
                    "LS_1": 586.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 483.6667, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 1990, 
                    "cog": "", 
                    "Gene id": "MSTRG.10063", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 181.6667, 
                    "HS_2": 300.0, 
                    "HS_3": 75.0, 
                    "HS_1": 170.0, 
                    "LS_2": 98.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 243.0, 
                    "LS_1": 376.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 239.0, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 577, 
                    "cog": "", 
                    "Gene id": "MSTRG.10065", 
                    "swissprot": ""
                }, 
                {
                    "cog_description": "", 
                    "HS": 8.6667, 
                    "HS_2": 16.0, 
                    "HS_3": 4.0, 
                    "HS_1": 6.0, 
                    "LS_2": 7.0, 
                    "Gene name": "", 
                    "go": "", 
                    "LS_3": 18.0, 
                    "LS_1": 6.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "KO_name": "", 
                    "LS": 10.3333, 
                    "Gene description": "", 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "length": 719, 
                    "cog": "", 
                    "Gene id": "MSTRG.10068", 
                    "swissprot": ""
                }
            ]
        }, 
        "table_8221": {
            "table_header": [
                {
                    "field": "Gene ID", 
                    "label": "Gene ID"
                }, 
                {
                    "field": "Gene Name", 
                    "label": "Gene Name"
                }, 
                {
                    "field": "Gene Description", 
                    "label": "Gene Description"
                }, 
                {
                    "field": "GO_id", 
                    "label": "GO_id"
                }, 
                {
                    "field": "GO_term", 
                    "label": "GO_term"
                }, 
                {
                    "field": "Go_description", 
                    "label": "Go_description"
                }, 
                {
                    "field": "KO_id", 
                    "label": "KO_id"
                }, 
                {
                    "field": "KO_name", 
                    "label": "KO_name"
                }, 
                {
                    "field": "Pathway_id", 
                    "label": "Pathway_id"
                }, 
                {
                    "field": "Pathway_definition", 
                    "label": "Pathway_definition"
                }, 
                {
                    "field": "COG_id", 
                    "label": "COG_id"
                }, 
                {
                    "field": "COG_Functional_Categories", 
                    "label": "COG_Functional_Categories"
                }, 
                {
                    "field": "NR_hit-name", 
                    "label": "NR_hit-name"
                }, 
                {
                    "field": "NR_description", 
                    "label": "NR_description"
                }, 
                {
                    "field": "Swiss-Prot_hit-name", 
                    "label": "Swiss-Prot_hit-name"
                }, 
                {
                    "field": "Swiss-Prot_description", 
                    "label": "Swiss-Prot_description"
                }, 
                {
                    "field": "Pfam_id", 
                    "label": "Pfam_id"
                }, 
                {
                    "field": "Domain", 
                    "label": "Domain"
                }, 
                {
                    "field": "Domain_description", 
                    "label": "Domain_description"
                }
            ], 
            "table": [
                {
                    "Pathway_id": "map04977", 
                    "Domain": "SSF", 
                    "KO_id": "K14388;K14386", 
                    "COG_Functional_Categories": "E:Amino acid transport and metabolism", 
                    "Pathway_definition": "Vitamin digestion and absorption", 
                    "Gene Description": "sodium-coupled monocarboxylate transporter 2-like, transcript variant X1", 
                    "Pfam_id": "PF00474.20", 
                    "GO_term": "molecular_function;cellular_component", 
                    "Domain_description": "Sodium", 
                    "NR_description": "sodium-coupled monocarboxylate transporter 2-like [Penaeus japonicus]", 
                    "GO_id": "GO:0022857;GO:0016021", 
                    "Swiss-Prot_description": "Sodium-coupled monocarboxylate transporter 2 OS=Danio rerio OX=7955 GN=slc5a12 PE=1 SV=1", 
                    "NR_hit-name": "XP_042863387.1", 
                    "Go_description": "MF:transmembrane transporter activity;CC:integral component of membrane", 
                    "Gene Name": "LOC122247826", 
                    "COG_id": "COG0591", 
                    "Gene ID": "gene-LOC122247826", 
                    "Swiss-Prot_hit-name": "sp|Q7T384|SC5AC_DANRE", 
                    "KO_name": "SLC5A8_12, SMCT;SLC5A6, SMVT"
                }, 
                {
                    "Pathway_id": "map04024;map04727;map04080;map04929;map04742;map04915;map05032", 
                    "Domain": "7tm_3;ANF_receptor;Peripla_BP_6", 
                    "KO_id": "K04615", 
                    "COG_Functional_Categories": "S:Function unknown", 
                    "Pathway_definition": "cAMP signaling pathway;GABAergic synapse;Neuroactive ligand-receptor interaction;GnRH secretion;Taste transduction;Estrogen signaling pathway;Morphine addiction", 
                    "Gene Description": "gamma-aminobutyric acid type B receptor subunit 1-like, transcript variant X1", 
                    "Pfam_id": "PF00003.25;PF01094.31;PF13458.9", 
                    "GO_term": "molecular_function;cellular_component", 
                    "Domain_description": "7 transmembrane sweet-taste receptor of 3 GCPR;Receptor family ligand binding region;Periplasmic binding protein", 
                    "NR_description": "gamma-aminobutyric acid type B receptor subunit 1-like isoform X1 [Penaeus japonicus]", 
                    "GO_id": "GO:0004965;GO:0016021", 
                    "Swiss-Prot_description": "Gamma-aminobutyric acid type B receptor subunit 1 OS=Homo sapiens OX=9606 GN=GABBR1 PE=1 SV=1", 
                    "NR_hit-name": "XP_042890500.1", 
                    "Go_description": "MF:G-protein coupled GABA receptor activity;CC:integral component of membrane", 
                    "Gene Name": "LOC122265324", 
                    "COG_id": "ENOG410XNN1", 
                    "Gene ID": "gene-LOC122265324", 
                    "Swiss-Prot_hit-name": "sp|Q9UBS5|GABR1_HUMAN", 
                    "KO_name": "GABBR"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "VIR_N", 
                    "KO_id": "K22910", 
                    "COG_Functional_Categories": "S:Function unknown", 
                    "Pathway_definition": "", 
                    "Gene Description": "protein virilizer-like, transcript variant X1", 
                    "Pfam_id": "PF15912.8", 
                    "GO_term": "", 
                    "Domain_description": "Virilizer, N-terminal", 
                    "NR_description": "protein virilizer-like isoform X1 [Penaeus japonicus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "Protein virilizer homolog OS=Mus musculus OX=10090 GN=Virma PE=1 SV=1", 
                    "NR_hit-name": "XP_042870657.1", 
                    "Go_description": "", 
                    "Gene Name": "LOC122252318", 
                    "COG_id": "ENOG410XSTI", 
                    "Gene ID": "gene-LOC122252318", 
                    "Swiss-Prot_hit-name": "sp|A2AIV2|VIR_MOUSE", 
                    "KO_name": "VIRMA"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "", 
                    "KO_id": "", 
                    "COG_Functional_Categories": "", 
                    "Pathway_definition": "", 
                    "Gene Description": "anti-sigma-I factor RsgI2-like", 
                    "Pfam_id": "", 
                    "GO_term": "", 
                    "Domain_description": "", 
                    "NR_description": "anti-sigma-I factor RsgI2-like [Penaeus japonicus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "", 
                    "NR_hit-name": "XP_042887426.1", 
                    "Go_description": "", 
                    "Gene Name": "LOC122263149", 
                    "COG_id": "", 
                    "Gene ID": "gene-LOC122263149", 
                    "Swiss-Prot_hit-name": "", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "TM2", 
                    "KO_id": "", 
                    "COG_Functional_Categories": "S:Function unknown", 
                    "Pathway_definition": "", 
                    "Gene Description": "TM2 domain-containing protein CG11103-like", 
                    "Pfam_id": "PF05154.19", 
                    "GO_term": "", 
                    "Domain_description": "TM2 domain", 
                    "NR_description": "TM2 domain-containing protein CG11103-like [Penaeus japonicus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "TM2 domain-containing protein CG11103 OS=Drosophila melanogaster OX=7227 GN=CG11103 PE=2 SV=3", 
                    "NR_hit-name": "XP_042885936.1", 
                    "Go_description": "", 
                    "Gene Name": "LOC122262076", 
                    "COG_id": "ENOG4111HBB", 
                    "Gene ID": "gene-LOC122262076", 
                    "Swiss-Prot_hit-name": "sp|Q9VY86|TM2D2_DROME", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "", 
                    "KO_id": "", 
                    "COG_Functional_Categories": "", 
                    "Pathway_definition": "", 
                    "Gene Description": "uncharacterized LOC122249222", 
                    "Pfam_id": "", 
                    "GO_term": "cellular_component", 
                    "Domain_description": "", 
                    "NR_description": "uncharacterized protein LOC122249222 [Penaeus japonicus]", 
                    "GO_id": "GO:0016021", 
                    "Swiss-Prot_description": "", 
                    "NR_hit-name": "XP_042865850.1", 
                    "Go_description": "CC:integral component of membrane", 
                    "Gene Name": "LOC122249222", 
                    "COG_id": "", 
                    "Gene ID": "gene-LOC122249222", 
                    "Swiss-Prot_hit-name": "", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "", 
                    "KO_id": "", 
                    "COG_Functional_Categories": "", 
                    "Pathway_definition": "", 
                    "Gene Description": "uncharacterized LOC122256209", 
                    "Pfam_id": "", 
                    "GO_term": "", 
                    "Domain_description": "", 
                    "NR_description": "uncharacterized protein LOC122256209 [Penaeus japonicus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "", 
                    "NR_hit-name": "XP_042876670.1", 
                    "Go_description": "", 
                    "Gene Name": "LOC122256209", 
                    "COG_id": "", 
                    "Gene ID": "gene-LOC122256209", 
                    "Swiss-Prot_hit-name": "", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "", 
                    "KO_id": "", 
                    "COG_Functional_Categories": "", 
                    "Pathway_definition": "", 
                    "Gene Description": "keratin-associated protein 9-1-like", 
                    "Pfam_id": "", 
                    "GO_term": "", 
                    "Domain_description": "", 
                    "NR_description": "keratin-associated protein 9-1-like [Penaeus japonicus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "", 
                    "NR_hit-name": "XP_042870632.1", 
                    "Go_description": "", 
                    "Gene Name": "LOC122252304", 
                    "COG_id": "", 
                    "Gene ID": "gene-LOC122252304", 
                    "Swiss-Prot_hit-name": "", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "Sugar_tr;MFS_1", 
                    "KO_id": "K14258", 
                    "COG_Functional_Categories": "G:Carbohydrate transport and metabolism", 
                    "Pathway_definition": "", 
                    "Gene Description": "facilitated trehalose transporter Tret1-like", 
                    "Pfam_id": "PF00083.27;PF07690.19", 
                    "GO_term": "molecular_function;cellular_component;biological_process", 
                    "Domain_description": "Sugar (and other) transporter;Major Facilitator Superfamily", 
                    "NR_description": "facilitated trehalose transporter Tret1-like [Penaeus japonicus]", 
                    "GO_id": "GO:0022857;GO:0016021;GO:0008643", 
                    "Swiss-Prot_description": "Facilitated trehalose transporter Tret1 OS=Culex quinquefasciatus OX=7176 GN=Tret1 PE=3 SV=1", 
                    "NR_hit-name": "XP_042886117.1", 
                    "Go_description": "MF:transmembrane transporter activity;CC:integral component of membrane;BP:carbohydrate transport", 
                    "Gene Name": "LOC122262218", 
                    "COG_id": "ENOG410XNQK", 
                    "Gene ID": "gene-LOC122262218", 
                    "Swiss-Prot_hit-name": "sp|B0WC46|TRET1_CULQU", 
                    "KO_name": "TRET1"
                }, 
                {
                    "Pathway_id": "map05206;map04935;map04931;map04150;map05010;map04960;map04151;map04068;map04920;map04923;map04910;map04152;map04022;map04213;map04212;map04211;map05415;map04932;map04722;map04930;map04140", 
                    "Domain": "IRS;PH", 
                    "KO_id": "K07187;K16172", 
                    "COG_Functional_Categories": "T:Signal transduction mechanisms", 
                    "Pathway_definition": "MicroRNAs in cancer;Growth hormone synthesis, secretion and action;Insulin resistance;mTOR signaling pathway;Alzheimer disease;Aldosterone-regulated sodium reabsorption;PI3K-Akt signaling pathway;FoxO signaling pathway;Adipocytokine signaling pathway;Regulation of lipolysis in adipocytes;Insulin signaling pathway;AMPK signaling pathway;cGMP-PKG signaling pathway;Longevity regulating pathway - multiple species;Longevity regulating pathway - worm;Longevity regulating pathway;Diabetic cardiomyopathy;Non-alcoholic fatty liver disease;Neurotrophin signaling pathway;Type II diabetes mellitus;Autophagy - animal", 
                    "Gene Description": "insulin receptor substrate 2-like, transcript variant X1", 
                    "Pfam_id": "PF02174.20;PF00169.32", 
                    "GO_term": "", 
                    "Domain_description": "PTB domain (IRS-1 type;PH domain", 
                    "NR_description": "dentin sialophosphoprotein-like isoform X1 [Penaeus japonicus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "Insulin receptor substrate 1 OS=Drosophila melanogaster OX=7227 GN=chico PE=1 SV=1", 
                    "NR_hit-name": "XP_042864161.1", 
                    "Go_description": "", 
                    "Gene Name": "LOC122248311", 
                    "COG_id": "ENOG410Z9EP", 
                    "Gene ID": "gene-LOC122248311", 
                    "Swiss-Prot_hit-name": "sp|Q9XTN2|IRS1_DROME", 
                    "KO_name": "IRS2;IRS1"
                }
            ]
        }, 
        "table_append_01": {
            "table_header": [
                {
                    "field": "software_database", 
                    "label": "Soft/Database"
                }, 
                {
                    "field": "version", 
                    "label": "Version"
                }, 
                {
                    "field": "usage", 
                    "label": "Analysis"
                }, 
                {
                    "field": "source", 
                    "label": "Source"
                }
            ], 
            "table": [
                {
                    "software_database": "TransDecoder", 
                    "source": "http://transdecoder.github.io/", 
                    "version": "Version 5.5.0", 
                    "usage": "多类数据库注释比较分析等"
                }, 
                {
                    "software_database": "SeqPrep", 
                    "source": "https://github.com/jstjohn/SeqPrep", 
                    "version": "--", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "edgeR", 
                    "source": "http://bioconductor.org/packages/stats/bioc/edgeR/", 
                    "version": "Version 3.24.3", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "GATK", 
                    "source": "https://software.broadinstitute.org/gatk/download/", 
                    "version": "Version 3.8", 
                    "usage": "SNP/Indel分析"
                }, 
                {
                    "software_database": "WGCNA", 
                    "source": "https://cran.r-project.org/web/packages/WGCNA/index.html", 
                    "version": "Version 1.63", 
                    "usage": "WGCNA分析"
                }, 
                {
                    "software_database": "STRING 数据库", 
                    "source": "https://string-db.org/", 
                    "version": "Version 11.5", 
                    "usage": "靶基因蛋白互作网络"
                }, 
                {
                    "software_database": "sva", 
                    "source": "http://www.bioconductor.org/packages/release/bioc/html/sva.html", 
                    "version": "Version 3.20.0", 
                    "usage": "移除批次效应影响"
                }, 
                {
                    "software_database": "kallisto", 
                    "source": "https://pachterlab.github.io/kallisto/download", 
                    "version": "Version 0.46.2", 
                    "usage": "表达量分析"
                }, 
                {
                    "software_database": "PlantTFDB", 
                    "source": "http://planttfdb_v4.cbi.pku.edu.cn/", 
                    "version": "Version 5.0", 
                    "usage": "转录因子预测"
                }, 
                {
                    "software_database": "fastx_toolkit", 
                    "source": "http://hannonlab.cshl.edu/fastx_toolkit/", 
                    "version": "Version 0.0.14", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "NOISeq", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/NOISeq.html", 
                    "version": "Version 2.18.0", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "Salmon", 
                    "source": "https://github.com/COMBINE-lab/salmon", 
                    "version": "Version 1.3.0", 
                    "usage": "表达量分析"
                }, 
                {
                    "software_database": "cufflinks", 
                    "source": "http://cole-trapnell-lab.github.io/cufflinks/", 
                    "version": "Version 2.2.1", 
                    "usage": "转录本组装"
                }, 
                {
                    "software_database": "Blast2go", 
                    "source": "https://www.blast2go.com/", 
                    "version": "Version 2.5", 
                    "usage": "GO注释"
                }, 
                {
                    "software_database": "STEM", 
                    "source": "http://www.cs.cmu.edu/~jernst/stem/", 
                    "version": "Version 1.3.11", 
                    "usage": "时序表达趋势分析"
                }, 
                {
                    "software_database": "MSigDB 数据库", 
                    "source": "http://software.broadinstitute.org/gsea/downloads.jsp", 
                    "version": "Version 6.2", 
                    "usage": "GSEA分析"
                }, 
                {
                    "software_database": "star_fusion", 
                    "source": "https://github.com/STAR-Fusion/STAR-Fusion/wiki", 
                    "version": "Version 1.8.1", 
                    "usage": "基因融合鉴定"
                }, 
                {
                    "software_database": "Sickle", 
                    "source": "https://github.com/najoshi/sickle", 
                    "version": "--", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "KOBAS", 
                    "source": "http://kobas.cbi.pku.edu.cn/download.php", 
                    "version": "Version 2.1.1", 
                    "usage": "功能注释分类（KEGG）"
                }, 
                {
                    "software_database": "GSEA", 
                    "source": "http://software.broadinstitute.org/gsea/index.jsp", 
                    "version": "Version 4.3.2", 
                    "usage": "GSEA分析"
                }, 
                {
                    "software_database": "Ipath 数据库", 
                    "source": "https://pathways.embl.de/", 
                    "version": "Version 3", 
                    "usage": "iPath代谢通路分析"
                }, 
                {
                    "software_database": "stringtie", 
                    "source": "https://ccb.jhu.edu/software/stringtie/", 
                    "version": "Version 2.1.2", 
                    "usage": "转录本组装"
                }, 
                {
                    "software_database": "fastp", 
                    "source": "https://github.com/OpenGene/fastp", 
                    "version": "0.19.5", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "TopHat", 
                    "source": "http://ccb.jhu.edu/software/tophat/index.shtml", 
                    "version": "Version v2.1.1", 
                    "usage": "序列比对分析"
                }, 
                {
                    "software_database": "DEGSeq", 
                    "source": "http://bioconductor.org/packages/stats/bioc/DEGSeq/", 
                    "version": "Version 1.38.0", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "Bowtie2", 
                    "source": "http://downloads.sourceforge.net/project/bowtie-bio/bowtie2/2.4.1", 
                    "version": "Version 2.4.1", 
                    "usage": "序列比对"
                }, 
                {
                    "software_database": "Diamond", 
                    "source": "https://github.com/bbuchfink/diamond", 
                    "version": "Version 0.9.24", 
                    "usage": "多类数据库注释比较分析等"
                }, 
                {
                    "software_database": "RSEM", 
                    "source": "http://deweylab.biostat.wisc.edu/rsem/", 
                    "version": "Version 1.3.3", 
                    "usage": "表达量分析"
                }, 
                {
                    "software_database": "ASprofile", 
                    "source": "http://ccb.jhu.edu/software/ASprofile/", 
                    "version": "Version 1.0", 
                    "usage": "可变剪切分析"
                }, 
                {
                    "software_database": "hisat2", 
                    "source": "http://ccb.jhu.edu/software/hisat2/index.shtml", 
                    "version": "Version 2.1.0", 
                    "usage": "序列比对分析"
                }, 
                {
                    "software_database": "JASPAR", 
                    "source": "http://jaspar.genereg.net/", 
                    "version": "Version 2020", 
                    "usage": "转录因子预测"
                }, 
                {
                    "software_database": "samtools", 
                    "source": "https://github.com/samtools/samtools.git ", 
                    "version": "Version 1.9", 
                    "usage": "SNP/Indel分析"
                }, 
                {
                    "software_database": "Limma", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/limma.html", 
                    "version": "Version 3.38.3", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "HMMER", 
                    "source": "ftp://selab.janelia.org/pub/software/hmmer3/3.0/hmmer-3.0.tar.gz", 
                    "version": "Version 3.2.1", 
                    "usage": "功能注释"
                }, 
                {
                    "software_database": "DESeq2", 
                    "source": "http://bioconductor.org/packages/stats/bioc/DESeq2/", 
                    "version": "Version 1.24.0", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "BLAST+", 
                    "source": "ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/2.9.0/", 
                    "version": "Version 2.9.0", 
                    "usage": "多类数据库注释比较分析等"
                }, 
                {
                    "software_database": "bedtools", 
                    "source": "https://bedtools.readthedocs.io/en/latest/", 
                    "version": "Version 2.27.1", 
                    "usage": "序列提取"
                }, 
                {
                    "software_database": "goatools", 
                    "source": "https://files.pythonhosted.org/packages/bb/7b/0c76e3511a79879606672e0741095a891dfb98cd63b1530ed8c51d406cda/goatools-0.8.9.tar.gz", 
                    "version": "Version 0.6.5", 
                    "usage": "基因集分析（GO富集）"
                }, 
                {
                    "software_database": "maSigPro", 
                    "source": "http://www.bioconductor.org/packages/release/bioc/html/maSigPro.html", 
                    "version": "Version 1.56.0", 
                    "usage": "时序差异聚类"
                }, 
                {
                    "software_database": "AnimalTFDB", 
                    "source": "http://bioinfo.life.hust.edu.cn/AnimalTFDB/#!/", 
                    "version": "Version 3.0", 
                    "usage": "转录因子预测"
                }, 
                {
                    "software_database": "STAR", 
                    "source": "http://code.google.com/p/rna-star/", 
                    "version": "Version 2.7.1a", 
                    "usage": "序列比对分析"
                }, 
                {
                    "software_database": "Mfuzz", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
                    "version": "Version 2.6.0", 
                    "usage": "Mfuzz时序分析"
                }, 
                {
                    "software_database": "Pfam 数据库", 
                    "source": "http://pfam.xfam.org/", 
                    "version": "Version 35.0", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "KEGG 数据库", 
                    "source": "http://www.genome.jp/kegg/", 
                    "version": "Version 2022.10", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "eggNOG 数据库", 
                    "source": "http://eggnogdb.embl.de/#/app/home", 
                    "version": "Version 2020.06", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "Rfam 数据库", 
                    "source": "http://rfam.janelia.org/", 
                    "version": "Version 14.8", 
                    "usage": "核糖体比例评估"
                }, 
                {
                    "software_database": "Swiss-prot 数据库", 
                    "source": "ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz", 
                    "version": "Version 2022.10", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "GO 数据库", 
                    "source": "http://www.geneontology.org/", 
                    "version": "Version 2022.0915", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "NR 数据库", 
                    "source": "https://www.ncbi.nlm.nih.gov/public/", 
                    "version": "Version 2022.10", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "Mfuzz", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
                    "version": "Version 2.6.0", 
                    "usage": "Mfuzz时序分析"
                }
            ]
        }, 
        "table_5651": {
            "table_header": [
                {
                    "field": "Sample", 
                    "label": "Sample"
                }, 
                {
                    "field": "Raw_reads", 
                    "label": "Raw_reads"
                }, 
                {
                    "field": "Raw_bases", 
                    "label": "Raw_bases"
                }, 
                {
                    "field": "Clean_reads", 
                    "label": "Clean_reads"
                }, 
                {
                    "field": "Clean_Bases", 
                    "label": "Clean_Bases"
                }, 
                {
                    "field": "Error%", 
                    "label": "Error%"
                }, 
                {
                    "field": "Q20%", 
                    "label": "Q20%"
                }, 
                {
                    "field": "Q30%", 
                    "label": "Q30%"
                }, 
                {
                    "field": "GC%", 
                    "label": "GC%"
                }
            ], 
            "table": [
                {
                    "GC%": 42.64, 
                    "Raw_reads": 43847238, 
                    "Sample": "HS_3", 
                    "Q30%": 95.54, 
                    "Clean_reads": 43402336, 
                    "Error%": 0.0123, 
                    "Clean_Bases": 6505228985, 
                    "Q20%": 98.52, 
                    "Raw_bases": 6620932938
                }, 
                {
                    "GC%": 41.26, 
                    "Raw_reads": 42363714, 
                    "Sample": "LS_1", 
                    "Q30%": 95.41, 
                    "Clean_reads": 41921834, 
                    "Error%": 0.0124, 
                    "Clean_Bases": 6264506201, 
                    "Q20%": 98.43, 
                    "Raw_bases": 6396920814
                }, 
                {
                    "GC%": 43.22, 
                    "Raw_reads": 43942944, 
                    "Sample": "HS_2", 
                    "Q30%": 95.31, 
                    "Clean_reads": 43495944, 
                    "Error%": 0.0124, 
                    "Clean_Bases": 6538223469, 
                    "Q20%": 98.44, 
                    "Raw_bases": 6635384544
                }, 
                {
                    "GC%": 40.02, 
                    "Raw_reads": 44100534, 
                    "Sample": "LS_2", 
                    "Q30%": 95.42, 
                    "Clean_reads": 43664664, 
                    "Error%": 0.0124, 
                    "Clean_Bases": 6548156713, 
                    "Q20%": 98.44, 
                    "Raw_bases": 6659180634
                }, 
                {
                    "GC%": 43.49, 
                    "Raw_reads": 42727014, 
                    "Sample": "LS_3", 
                    "Q30%": 94.47, 
                    "Clean_reads": 42173110, 
                    "Error%": 0.0129, 
                    "Clean_Bases": 6317909289, 
                    "Q20%": 98.12, 
                    "Raw_bases": 6451779114
                }, 
                {
                    "GC%": 43.12, 
                    "Raw_reads": 42596170, 
                    "Sample": "HS_1", 
                    "Q30%": 95.54, 
                    "Clean_reads": 42195900, 
                    "Error%": 0.0123, 
                    "Clean_Bases": 6324716288, 
                    "Q20%": 98.49, 
                    "Raw_bases": 6432021670
                }
            ]
        }, 
        "table_5763": {
            "table_header": [
                {
                    "field": "Region", 
                    "label": "Region"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "Region": ".", 
                    "HS_2": 0, 
                    "HS_3": 0, 
                    "HS_1": 0, 
                    "LS_2": 0, 
                    "LS_3": 0, 
                    "LS_1": 0
                }, 
                {
                    "Region": "UTR3", 
                    "HS_2": 63186, 
                    "HS_3": 47547, 
                    "HS_1": 72478, 
                    "LS_2": 75421, 
                    "LS_3": 86140, 
                    "LS_1": 67702
                }, 
                {
                    "Region": "UTR5", 
                    "HS_2": 11537, 
                    "HS_3": 8298, 
                    "HS_1": 13848, 
                    "LS_2": 10767, 
                    "LS_3": 16477, 
                    "LS_1": 10646
                }, 
                {
                    "Region": "UTR5;UTR3", 
                    "HS_2": 30, 
                    "HS_3": 26, 
                    "HS_1": 26, 
                    "LS_2": 29, 
                    "LS_3": 30, 
                    "LS_1": 28
                }, 
                {
                    "Region": "downstream", 
                    "HS_2": 12413, 
                    "HS_3": 7945, 
                    "HS_1": 15998, 
                    "LS_2": 16279, 
                    "LS_3": 19616, 
                    "LS_1": 15962
                }, 
                {
                    "Region": "exonic", 
                    "HS_2": 102541, 
                    "HS_3": 74415, 
                    "HS_1": 121056, 
                    "LS_2": 106306, 
                    "LS_3": 147976, 
                    "LS_1": 101177
                }, 
                {
                    "Region": "exonic;splicing", 
                    "HS_2": 8, 
                    "HS_3": 8, 
                    "HS_1": 8, 
                    "LS_2": 8, 
                    "LS_3": 6, 
                    "LS_1": 8
                }, 
                {
                    "Region": "intergenic", 
                    "HS_2": 23101, 
                    "HS_3": 14241, 
                    "HS_1": 32159, 
                    "LS_2": 33481, 
                    "LS_3": 43412, 
                    "LS_1": 34808
                }, 
                {
                    "Region": "intronic", 
                    "HS_2": 15445, 
                    "HS_3": 8142, 
                    "HS_1": 20911, 
                    "LS_2": 15054, 
                    "LS_3": 23609, 
                    "LS_1": 17848
                }, 
                {
                    "Region": "ncRNA_UTR3", 
                    "HS_2": 105, 
                    "HS_3": 80, 
                    "HS_1": 118, 
                    "LS_2": 116, 
                    "LS_3": 119, 
                    "LS_1": 95
                }
            ]
        }, 
        "table_5631": {
            "table_header": [
                {
                    "field": "Length", 
                    "label": "Length"
                }, 
                {
                    "field": "Number", 
                    "label": "Number"
                }
            ], 
            "table": [
                {
                    "Length": "0~200", 
                    "Number": 2281
                }, 
                {
                    "Length": "201~400", 
                    "Number": 2282
                }, 
                {
                    "Length": "401~600", 
                    "Number": 3595
                }, 
                {
                    "Length": "601~800", 
                    "Number": 3346
                }, 
                {
                    "Length": "801~1000", 
                    "Number": 3015
                }, 
                {
                    "Length": "1001~1200", 
                    "Number": 2800
                }, 
                {
                    "Length": "1201~1400", 
                    "Number": 2656
                }, 
                {
                    "Length": "1401~1600", 
                    "Number": 2619
                }, 
                {
                    "Length": "1601~1800", 
                    "Number": 2576
                }, 
                {
                    "Length": ">1800", 
                    "Number": 30204
                }
            ]
        }, 
        "table_5633": {
            "table_header": [
                {
                    "field": "Unnamed: 0", 
                    "label": "Unnamed: 0"
                }, 
                {
                    "field": "Expre_Gene number(percent)", 
                    "label": "Expre_Gene number(percent)"
                }, 
                {
                    "field": "Expre_Transcript number(percent)", 
                    "label": "Expre_Transcript number(percent)"
                }, 
                {
                    "field": "All_Gene number(percent)", 
                    "label": "All_Gene number(percent)"
                }, 
                {
                    "field": "All_Transcript number(percent)", 
                    "label": "All_Transcript number(percent)"
                }
            ], 
            "table": [
                {
                    "Expre_Gene number(percent)": "10862(0.5316)", 
                    "Expre_Transcript number(percent)": "20150(0.4835)", 
                    "Unnamed: 0": "GO", 
                    "All_Transcript number(percent)": "25269(0.4563)", 
                    "All_Gene number(percent)": "13845(0.4789)"
                }, 
                {
                    "Expre_Gene number(percent)": "10561(0.5169)", 
                    "Expre_Transcript number(percent)": "24035(0.5768)", 
                    "Unnamed: 0": "KEGG", 
                    "All_Transcript number(percent)": "29234(0.5279)", 
                    "All_Gene number(percent)": "12811(0.4431)"
                }, 
                {
                    "Expre_Gene number(percent)": "13527(0.662)", 
                    "Expre_Transcript number(percent)": "30338(0.728)", 
                    "Unnamed: 0": "COG", 
                    "All_Transcript number(percent)": "37386(0.6752)", 
                    "All_Gene number(percent)": "16682(0.577)"
                }, 
                {
                    "Expre_Gene number(percent)": "18171(0.8893)", 
                    "Expre_Transcript number(percent)": "38604(0.9264)", 
                    "Unnamed: 0": "NR", 
                    "All_Transcript number(percent)": "51151(0.9237)", 
                    "All_Gene number(percent)": "25603(0.8855)"
                }, 
                {
                    "Expre_Gene number(percent)": "12600(0.6166)", 
                    "Expre_Transcript number(percent)": "28597(0.6862)", 
                    "Unnamed: 0": "Swiss-Prot", 
                    "All_Transcript number(percent)": "34929(0.6308)", 
                    "All_Gene number(percent)": "15303(0.5293)"
                }, 
                {
                    "Expre_Gene number(percent)": "13839(0.6773)", 
                    "Expre_Transcript number(percent)": "30625(0.7349)", 
                    "Unnamed: 0": "Pfam", 
                    "All_Transcript number(percent)": "37861(0.6837)", 
                    "All_Gene number(percent)": "17157(0.5934)"
                }, 
                {
                    "Expre_Gene number(percent)": "18219(0.8916)", 
                    "Expre_Transcript number(percent)": "38682(0.9282)", 
                    "Unnamed: 0": "Total_anno", 
                    "All_Transcript number(percent)": "51251(0.9255)", 
                    "All_Gene number(percent)": "25673(0.8879)"
                }, 
                {
                    "Expre_Gene number(percent)": "20433(1)", 
                    "Expre_Transcript number(percent)": "41673(1)", 
                    "Unnamed: 0": "Total", 
                    "All_Transcript number(percent)": "55374(1.0)", 
                    "All_Gene number(percent)": "28913(1.0)"
                }
            ]
        }, 
        "table_5721": {
            "table_header": [
                {
                    "field": "seq_id", 
                    "label": "seq_id"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "seq_id": "gene-LOC122247243", 
                    "HS_2": -0.355228335513, 
                    "HS_3": -1.61938934379, 
                    "HS_1": 1.1220044466799999, 
                    "LS_2": -0.35470831531900004, 
                    "LS_3": 1.35793736631, 
                    "LS_1": -0.15061581836899998
                }
            ]
        }, 
        "table_5727": {
            "table_header": [
                {
                    "field": "Term type", 
                    "label": "Term type"
                }, 
                {
                    "field": "Description", 
                    "label": "Description"
                }, 
                {
                    "field": "GO ID", 
                    "label": "GO ID"
                }, 
                {
                    "field": "HS_vs_LS_G num", 
                    "label": "HS_vs_LS_G num"
                }, 
                {
                    "field": "HS_vs_LS_G percent", 
                    "label": "HS_vs_LS_G percent"
                }, 
                {
                    "field": "HS_vs_LS_G list", 
                    "label": "HS_vs_LS_G list"
                }
            ], 
            "table": [
                {
                    "Description": "immune system process", 
                    "GO ID": "GO:0002376", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(1/470)", 
                    "HS_vs_LS_G num": 1, 
                    "HS_vs_LS_G list": "gene-LOC122248640"
                }, 
                {
                    "Description": "biological regulation", 
                    "GO ID": "GO:0065007", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(18/470)", 
                    "HS_vs_LS_G num": 18, 
                    "HS_vs_LS_G list": "gene-LOC122247625;gene-LOC122252392;gene-LOC122248640;gene-LOC122243067;gene-LOC122247211;gene-LOC122257959;gene-LOC122260966;gene-LOC122249154;gene-LOC122264559;gene-LOC122252041;gene-LOC122248528;gene-LOC122244302;gene-LOC122267462;gene-LOC122259561;gene-LOC122242521;gene-LOC122266517;gene-LOC122253122;gene-LOC122245501"
                }, 
                {
                    "Description": "metabolic process", 
                    "GO ID": "GO:0008152", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(72/470)", 
                    "HS_vs_LS_G num": 72, 
                    "HS_vs_LS_G list": "gene-LOC122253962;gene-LOC122266248;gene-LOC122251240;gene-LOC122251681;gene-LOC122257729;gene-LOC122251692;gene-LOC122250665;gene-LOC122251907;gene-LOC122260966;gene-LOC122257722;gene-LOC122265427;gene-LOC122264861;gene-LOC122253882;gene-LOC122248074;gene-LOC122256357;gene-LOC122262377;gene-LOC122249694;gene-LOC122243365;gene-LOC122247127;gene-LOC122253422;gene-LOC122255636;gene-LOC122247625;gene-LOC122261358;gene-LOC122260629;gene-LOC122249911;gene-LOC122263489;gene-LOC122250950;gene-LOC122251929;gene-LOC122256701;gene-LOC122242170;gene-LOC122262223;gene-LOC122263421;gene-LOC122254329;gene-LOC122250664;gene-LOC122251129;gene-LOC122251087;gene-LOC122252663;gene-LOC122265394;gene-LOC122255991;gene-LOC122255789;gene-LOC122258887;gene-LOC122260968;gene-LOC122243983;gene-LOC122267174;gene-LOC122265439;gene-LOC122243412;gene-LOC122257399;gene-LOC122254904;gene-LOC122252565;gene-LOC122267435;gene-LOC122246635;gene-LOC122245654;gene-LOC122252563;gene-LOC122250845;gene-LOC122264106;gene-LOC122248640;gene-LOC122255994;gene-LOC122255670;gene-LOC122254032;gene-LOC122263200;gene-LOC122262192;gene-LOC122248649;gene-LOC122259390;gene-LOC122260125;gene-LOC122268081;gene-LOC122247694;gene-LOC122263008;gene-LOC122258390;gene-LOC122251701;gene-LOC122267098;gene-LOC122266931;gene-LOC122252562"
                }, 
                {
                    "Description": "multi-organism process", 
                    "GO ID": "GO:0051704", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(2/470)", 
                    "HS_vs_LS_G num": 2, 
                    "HS_vs_LS_G list": "gene-LOC122248327;gene-LOC122248329"
                }, 
                {
                    "Description": "reproductive process", 
                    "GO ID": "GO:0022414", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(4/470)", 
                    "HS_vs_LS_G num": 4, 
                    "HS_vs_LS_G list": "gene-LOC122250102;gene-LOC122264904;gene-LOC122242887;gene-LOC122250143"
                }, 
                {
                    "Description": "cellular component organization or biogenesis", 
                    "GO ID": "GO:0071840", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(5/470)", 
                    "HS_vs_LS_G num": 5, 
                    "HS_vs_LS_G list": "gene-LOC122247412;gene-LOC122248410;gene-LOC122264670;gene-LOC122264481;gene-LOC122250477"
                }, 
                {
                    "Description": "cellular process", 
                    "GO ID": "GO:0009987", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(42/470)", 
                    "HS_vs_LS_G num": 42, 
                    "HS_vs_LS_G list": "gene-LOC122242521;gene-LOC122252392;gene-LOC122251240;gene-LOC122250477;gene-LOC122256701;gene-LOC122265427;gene-LOC122264559;gene-LOC122252041;gene-LOC122256357;gene-LOC122244302;gene-LOC122243365;gene-LOC122247412;gene-LOC122247127;gene-LOC122253422;gene-LOC122264670;gene-LOC122255636;gene-LOC122247625;gene-LOC122263489;gene-LOC122250950;gene-LOC122251929;gene-LOC122242887;gene-LOC122254329;gene-LOC122259123;gene-LOC122249154;gene-LOC122251087;gene-LOC122251692;gene-LOC122264904;gene-LOC122260966;gene-LOC122255789;gene-LOC122264481;gene-LOC122267462;gene-LOC122254904;gene-LOC122245501;gene-LOC122253882;gene-LOC122260125;gene-LOC122268081;gene-LOC122257399;gene-LOC122258390;gene-LOC122250102;gene-LOC122248410;gene-LOC122267098;gene-LOC122266931"
                }, 
                {
                    "Description": "developmental process", 
                    "GO ID": "GO:0032502", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(5/470)", 
                    "HS_vs_LS_G num": 5, 
                    "HS_vs_LS_G list": "gene-LOC122266377;gene-LOC122250102;gene-LOC122264904;gene-LOC122242887;gene-LOC122250477"
                }, 
                {
                    "Description": "multicellular organismal process", 
                    "GO ID": "GO:0032501", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(1/470)", 
                    "HS_vs_LS_G num": 1, 
                    "HS_vs_LS_G list": "gene-LOC122245790"
                }, 
                {
                    "Description": "rhythmic process", 
                    "GO ID": "GO:0048511", 
                    "Term type": "biological_process", 
                    "HS_vs_LS_G percent": "0.0(1/470)", 
                    "HS_vs_LS_G num": 1, 
                    "HS_vs_LS_G list": "gene-LOC122256128"
                }
            ]
        }, 
        "table_9949": {
            "table_header": [
                {
                    "field": "GENE(in or nearby)", 
                    "label": "GENE(in or nearby)"
                }, 
                {
                    "field": "Gene name", 
                    "label": "Gene name"
                }, 
                {
                    "field": "Gene description", 
                    "label": "Gene description"
                }, 
                {
                    "field": "Chrom", 
                    "label": "Chrom"
                }, 
                {
                    "field": "Start", 
                    "label": "Start"
                }, 
                {
                    "field": "End", 
                    "label": "End"
                }, 
                {
                    "field": "Ref", 
                    "label": "Ref"
                }, 
                {
                    "field": "Alt", 
                    "label": "Alt"
                }, 
                {
                    "field": "Total depth", 
                    "label": "Total depth"
                }, 
                {
                    "field": "QUAL", 
                    "label": "QUAL"
                }, 
                {
                    "field": "Anno", 
                    "label": "Anno"
                }, 
                {
                    "field": "MUT type", 
                    "label": "MUT type"
                }, 
                {
                    "field": "MUT info", 
                    "label": "MUT info"
                }, 
                {
                    "field": "HS_1_sampledepth", 
                    "label": "HS_1_sampledepth"
                }, 
                {
                    "field": "HS_1genotype", 
                    "label": "HS_1genotype"
                }, 
                {
                    "field": "HS_2_sampledepth", 
                    "label": "HS_2_sampledepth"
                }, 
                {
                    "field": "HS_2genotype", 
                    "label": "HS_2genotype"
                }, 
                {
                    "field": "HS_3_sampledepth", 
                    "label": "HS_3_sampledepth"
                }, 
                {
                    "field": "HS_3genotype", 
                    "label": "HS_3genotype"
                }, 
                {
                    "field": "LS_1_sampledepth", 
                    "label": "LS_1_sampledepth"
                }, 
                {
                    "field": "LS_1genotype", 
                    "label": "LS_1genotype"
                }, 
                {
                    "field": "LS_2_sampledepth", 
                    "label": "LS_2_sampledepth"
                }, 
                {
                    "field": "LS_2genotype", 
                    "label": "LS_2genotype"
                }, 
                {
                    "field": "LS_3_sampledepth", 
                    "label": "LS_3_sampledepth"
                }, 
                {
                    "field": "LS_3genotype", 
                    "label": "LS_3genotype"
                }, 
                {
                    "field": "type", 
                    "label": "type"
                }
            ], 
            "table": [
                {
                    "End": 72978, 
                    "Gene description": "-;;homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intergenic", 
                    "Start": 72978, 
                    "Gene name": "-;;LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,0", 
                    "LS_1genotype": "A/A", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 3, 
                    "Ref": "A", 
                    "HS_2_sampledepth": "0,2", 
                    "HS_3_sampledepth": "0,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "./.", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "NONE(dist=NONE),gene-LOC122242079(dist=33025)", 
                    "LS_2genotype": "./.", 
                    "HS_2genotype": "G/G", 
                    "LS_1_sampledepth": "1,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 106205, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "UTR3", 
                    "Start": 106205, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,38", 
                    "LS_2_sampledepth": "0,38", 
                    "LS_1genotype": "T/T", 
                    "LS_3_sampledepth": "0,44", 
                    "HS_1genotype": "T/T", 
                    "type": "snp", 
                    "Total depth": 194, 
                    "Ref": "A", 
                    "HS_2_sampledepth": "0,21", 
                    "HS_3_sampledepth": "0,22", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "T/T", 
                    "QUAL": 6986.93, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "T/T", 
                    "HS_2genotype": "T/T", 
                    "LS_1_sampledepth": "0,29", 
                    "LS_3genotype": "T/T", 
                    "Alt": "T", 
                    "MUT type": "."
                }, 
                {
                    "End": 254844, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 254844, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,2", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 2, 
                    "Ref": "T", 
                    "HS_2_sampledepth": "0,0", 
                    "HS_3_sampledepth": "0,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "./.", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "G/G", 
                    "HS_2genotype": "./.", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 254848, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 254848, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,2", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 2, 
                    "Ref": "C", 
                    "HS_2_sampledepth": "0,0", 
                    "HS_3_sampledepth": "0,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "./.", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "G/G", 
                    "HS_2genotype": "./.", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 254871, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 254871, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,2", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 2, 
                    "Ref": "C", 
                    "HS_2_sampledepth": "0,0", 
                    "HS_3_sampledepth": "0,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "./.", 
                    "QUAL": 45.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "G/G", 
                    "HS_2genotype": "./.", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 328263, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 328263, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,0", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 3, 
                    "Ref": "A", 
                    "HS_2_sampledepth": "0,2", 
                    "HS_3_sampledepth": "1,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "A/A", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "./.", 
                    "HS_2genotype": "G/G", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 328269, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 328269, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,0", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 3, 
                    "Ref": "T", 
                    "HS_2_sampledepth": "0,2", 
                    "HS_3_sampledepth": "1,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "T/T", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "./.", 
                    "HS_2genotype": "C/C", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "C", 
                    "MUT type": "."
                }, 
                {
                    "End": 328593, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 328593, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,0", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 2, 
                    "Ref": "A", 
                    "HS_2_sampledepth": "0,0", 
                    "HS_3_sampledepth": "0,2", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "T/T", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "./.", 
                    "HS_2genotype": "./.", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "T", 
                    "MUT type": "."
                }, 
                {
                    "End": 328613, 
                    "Gene description": "homeotic protein ultrabithorax-like, transcript variant X6", 
                    "Anno": "intronic", 
                    "Start": 328613, 
                    "Gene name": "LOC122242079", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,0", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 2, 
                    "Ref": "T", 
                    "HS_2_sampledepth": "0,0", 
                    "HS_3_sampledepth": "0,2", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "A/A", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-LOC122242079", 
                    "LS_2genotype": "./.", 
                    "HS_2genotype": "./.", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "A", 
                    "MUT type": "."
                }, 
                {
                    "End": 728457, 
                    "Gene description": "tRNA-Sec;;homeobox protein abdominal-A homolog", 
                    "Anno": "intergenic", 
                    "Start": 728457, 
                    "Gene name": "Trnastop-uca;;LOC122246316", 
                    "HS_1_sampledepth": "0,0", 
                    "LS_2_sampledepth": "0,0", 
                    "LS_1genotype": "./.", 
                    "LS_3_sampledepth": "0,0", 
                    "HS_1genotype": "./.", 
                    "type": "snp", 
                    "Total depth": 2, 
                    "Ref": "T", 
                    "HS_2_sampledepth": "0,2", 
                    "HS_3_sampledepth": "0,0", 
                    "MUT info": ".", 
                    "Chrom": "NW_025029446.1", 
                    "HS_3genotype": "./.", 
                    "QUAL": 65.9, 
                    "GENE(in or nearby)": "gene-Trnastop-uca(dist=229200),gene-LOC122246316(dist=430539)", 
                    "LS_2genotype": "./.", 
                    "HS_2genotype": "C/C", 
                    "LS_1_sampledepth": "0,0", 
                    "LS_3genotype": "./.", 
                    "Alt": "C", 
                    "MUT type": "."
                }
            ]
        }, 
        "table_append_02": {
            "table_header": [
                {
                    "field": "format", 
                    "label": "结果文件格式"
                }, 
                {
                    "field": "summary", 
                    "label": "结果文件说明"
                }, 
                {
                    "field": "use", 
                    "label": "结果文件查看方式"
                }
            ], 
            "table": [
                {
                    "use": "unix/Linux/Mac用户使用display命令打开。\nwindows用户可以使用图片浏览器打开，如photoshop等。", 
                    "summary": "结果图像文件，位图，无损压缩。", 
                    "format": "PNG"
                }, 
                {
                    "use": "unix/Linux/Mac用户使用display命令打开。\nwindows用户可以使用图片浏览器打开如photoshop等。", 
                    "summary": "结果图像文件，位图，有损压缩。", 
                    "format": "JPEG"
                }, 
                {
                    "use": "unix/Linux/Mac用户使用display命令打开。\nwindows用户可以使用图片浏览器打开，如photoshop等。", 
                    "summary": "结果图像文件，矢量图，可放大、缩小不失真，方便用户查看和编辑处理，可使用Adobe Illustrator进行编辑，用于文章发表等。", 
                    "format": "SVG"
                }, 
                {
                    "use": "unix/Linux/Mac用户使用 less 或 more 命令查看. \nwindows用户使用高级文本编辑器Editplus/Notepad++等，也可以用MicrosoftExcel打开。", 
                    "summary": "结果数据表格结果，文件以制表符 <Tab> 分隔", 
                    "format": "xls，CSV"
                }, 
                {
                    "use": "unix/Linux用户使用evince命令打开。windows/Mac用户可以使用Adobe Reader/福昕阅读器/网页浏览器等打开。", 
                    "summary": "结果图像文件，矢量图，可放大、缩小不失真，方便用户查看和编辑处理，可使用Adobe Illustrator进行编辑，用于文章发表等。", 
                    "format": "PDF"
                }
            ]
        }, 
        "table_7209": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "HS_vs_LS", 
                    "label": "HS_vs_LS"
                }, 
                {
                    "field": "sum", 
                    "label": "sum"
                }
            ], 
            "table": [
                {
                    "Gene id": "470", 
                    "sum": 470, 
                    "HS_vs_LS": "470"
                }, 
                {
                    "Gene id": "gene-LOC122262956", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC122251240", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC122251241", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|down"
                }, 
                {
                    "Gene id": "gene-LOC122252512", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC122267029", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC122262958", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|down"
                }, 
                {
                    "Gene id": "gene-LOC122264630", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC122244302", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|down"
                }, 
                {
                    "Gene id": "gene-LOC122249694", 
                    "sum": 1, 
                    "HS_vs_LS": "yes|up"
                }
            ]
        }, 
        "table_7207": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "Gene name", 
                    "label": "Gene name"
                }, 
                {
                    "field": "Gene description", 
                    "label": "Gene description"
                }, 
                {
                    "field": "length", 
                    "label": "length"
                }, 
                {
                    "field": "HS_1_count", 
                    "label": "HS_1_count"
                }, 
                {
                    "field": "HS_2_count", 
                    "label": "HS_2_count"
                }, 
                {
                    "field": "HS_3_count", 
                    "label": "HS_3_count"
                }, 
                {
                    "field": "LS_1_count", 
                    "label": "LS_1_count"
                }, 
                {
                    "field": "LS_2_count", 
                    "label": "LS_2_count"
                }, 
                {
                    "field": "LS_3_count", 
                    "label": "LS_3_count"
                }, 
                {
                    "field": "HS_1_tpm", 
                    "label": "HS_1_tpm"
                }, 
                {
                    "field": "HS_2_tpm", 
                    "label": "HS_2_tpm"
                }, 
                {
                    "field": "HS_3_tpm", 
                    "label": "HS_3_tpm"
                }, 
                {
                    "field": "LS_1_tpm", 
                    "label": "LS_1_tpm"
                }, 
                {
                    "field": "LS_2_tpm", 
                    "label": "LS_2_tpm"
                }, 
                {
                    "field": "LS_3_tpm", 
                    "label": "LS_3_tpm"
                }, 
                {
                    "field": "HS_tpm", 
                    "label": "HS_tpm"
                }, 
                {
                    "field": "LS_tpm", 
                    "label": "LS_tpm"
                }, 
                {
                    "field": "fc", 
                    "label": "fc"
                }, 
                {
                    "field": "log2fc", 
                    "label": "log2fc"
                }, 
                {
                    "field": "pvalue", 
                    "label": "pvalue"
                }, 
                {
                    "field": "padjust", 
                    "label": "padjust"
                }, 
                {
                    "field": "significant", 
                    "label": "significant"
                }, 
                {
                    "field": "regulate", 
                    "label": "regulate"
                }, 
                {
                    "field": "nr", 
                    "label": "nr"
                }, 
                {
                    "field": "go", 
                    "label": "go"
                }, 
                {
                    "field": "KO_id", 
                    "label": "KO_id"
                }, 
                {
                    "field": "KO_name", 
                    "label": "KO_name"
                }, 
                {
                    "field": "paths", 
                    "label": "paths"
                }, 
                {
                    "field": "cog", 
                    "label": "cog"
                }, 
                {
                    "field": "cog_description", 
                    "label": "cog_description"
                }, 
                {
                    "field": "pfam", 
                    "label": "pfam"
                }, 
                {
                    "field": "swissprot", 
                    "label": "swissprot"
                }, 
                {
                    "field": "entrez", 
                    "label": "entrez"
                }
            ], 
            "table": [
                {
                    "cog_description": "COG0591(symporter)", 
                    "padjust": 1.0, 
                    "LS_2_tpm": 0.05, 
                    "Gene description": "sodium-coupled monocarboxylate transporter 2-like, transcript variant X1", 
                    "LS_3_count": 1.0, 
                    "swissprot": "sp|Q7T384|SC5AC_DANRE(Sodium-coupled monocarboxylate transporter 2 OS=Danio rerio OX=7955 GN=slc5a12 PE=1 SV=1)", 
                    "HS_3_tpm": 0.0, 
                    "LS_tpm": 0.05, 
                    "Gene name": "LOC122247826", 
                    "log2fc": -0.123318366923, 
                    "go": "GO:0022857(molecular_function:transmembrane transporter activity); GO:0016021(cellular_component:integral component of membrane)", 
                    "regulate": "down", 
                    "HS_2_tpm": 0.06, 
                    "paths": "map04977(Vitamin digestion and absorption)", 
                    "KO_id": "K14388;K14386", 
                    "HS_tpm": 0.02, 
                    "HS_1_tpm": 0.0, 
                    "LS_1_count": 1.0, 
                    "LS_2_count": 1.0, 
                    "KO_name": "SLC5A8_12, SMCT;SLC5A6, SMVT", 
                    "LS_3_tpm": 0.06, 
                    "nr": "XP_042863387.1(sodium-coupled monocarboxylate transporter 2-like [Penaeus japonicus])", 
                    "HS_3_count": 0.0, 
                    "cog": "COG0591(E:Amino acid transport and metabolism)", 
                    "fc": 0.918073543942, 
                    "significant": "no", 
                    "LS_1_tpm": 0.04, 
                    "entrez": 122247826.0, 
                    "pfam": "PF00474.20(SSF:Sodium:solute symporter family)", 
                    "HS_1_count": 0.0, 
                    "length": 1757, 
                    "HS_2_count": 2.0, 
                    "Gene id": "gene-LOC122247826", 
                    "pvalue": 0.9649631361200001
                }, 
                {
                    "cog_description": "ENOG410XNN1(Gamma-aminobutyric acid (GABA) B receptor)", 
                    "padjust": 0.006749439139520001, 
                    "LS_2_tpm": 2.55, 
                    "Gene description": "gamma-aminobutyric acid type B receptor subunit 1-like, transcript variant X1", 
                    "LS_3_count": 163.99, 
                    "swissprot": "sp|Q9UBS5|GABR1_HUMAN(Gamma-aminobutyric acid type B receptor subunit 1 OS=Homo sapiens OX=9606 GN=GABBR1 PE=1 SV=1)", 
                    "HS_3_tpm": 0.18, 
                    "LS_tpm": 2.68, 
                    "Gene name": "LOC122265324", 
                    "log2fc": -1.80808817151, 
                    "go": "GO:0004965(molecular_function:G-protein coupled GABA receptor activity); GO:0016021(cellular_component:integral component of membrane)", 
                    "regulate": "down", 
                    "HS_2_tpm": 0.51, 
                    "paths": "map04024(cAMP signaling pathway); map04727(GABAergic synapse); map04080(Neuroactive ligand-receptor interaction); map04929(GnRH secretion); map04742(Taste transduction); map04915(Estrogen signaling pathway); map05032(Morphine addiction)", 
                    "KO_id": "K04615", 
                    "HS_tpm": 0.51, 
                    "HS_1_tpm": 0.84, 
                    "LS_1_count": 91.0, 
                    "LS_2_count": 109.0, 
                    "KO_name": "GABBR", 
                    "LS_3_tpm": 3.51, 
                    "nr": "XP_042890500.1(gamma-aminobutyric acid type B receptor subunit 1-like isoform X1 [Penaeus japonicus])", 
                    "HS_3_count": 10.0, 
                    "cog": "ENOG410XNN1(S:Function unknown)", 
                    "fc": 0.28556910838599997, 
                    "significant": "yes", 
                    "LS_1_tpm": 1.98, 
                    "entrez": 122265324.0, 
                    "pfam": "PF00003.25(7tm_3:7 transmembrane sweet-taste receptor of 3 GCPR); PF01094.31(ANF_receptor:Receptor family ligand binding region); PF13458.9(Peripla_BP_6:Periplasmic binding protein)", 
                    "HS_1_count": 50.08, 
                    "length": 5722, 
                    "HS_2_count": 24.0, 
                    "Gene id": "gene-LOC122265324", 
                    "pvalue": 0.000110926962281
                }, 
                {
                    "cog_description": "ENOG410XSTI(primary sex determination, soma)", 
                    "padjust": 0.650622580606, 
                    "LS_2_tpm": 2.29, 
                    "Gene description": "protein virilizer-like, transcript variant X1", 
                    "LS_3_count": 932.0, 
                    "swissprot": "sp|A2AIV2|VIR_MOUSE(Protein virilizer homolog OS=Mus musculus OX=10090 GN=Virma PE=1 SV=1)", 
                    "HS_3_tpm": 0.64, 
                    "LS_tpm": 5.07333333333, 
                    "Gene name": "LOC122252318", 
                    "log2fc": -0.428326694293, 
                    "go": "", 
                    "regulate": "down", 
                    "HS_2_tpm": 1.72, 
                    "paths": "", 
                    "KO_id": "K22910", 
                    "HS_tpm": 2.42666666667, 
                    "HS_1_tpm": 4.92, 
                    "LS_1_count": 415.0, 
                    "LS_2_count": 270.0, 
                    "KO_name": "VIRMA", 
                    "LS_3_tpm": 9.16, 
                    "nr": "XP_042870657.1(protein virilizer-like isoform X1 [Penaeus japonicus])", 
                    "HS_3_count": 108.0, 
                    "cog": "ENOG410XSTI(S:Function unknown)", 
                    "fc": 0.743123194973, 
                    "significant": "no", 
                    "LS_1_tpm": 3.77, 
                    "entrez": 122252318.0, 
                    "pfam": "PF15912.8(VIR_N:Virilizer, N-terminal)", 
                    "HS_1_count": 564.0, 
                    "length": 7294, 
                    "HS_2_count": 264.0, 
                    "Gene id": "gene-LOC122252318", 
                    "pvalue": 0.351718942085
                }, 
                {
                    "cog_description": "", 
                    "padjust": 1.0, 
                    "LS_2_tpm": 0.0, 
                    "Gene description": "anti-sigma-I factor RsgI2-like", 
                    "LS_3_count": 0.0, 
                    "swissprot": "", 
                    "HS_3_tpm": 0.0, 
                    "LS_tpm": 0.0, 
                    "Gene name": "LOC122263149", 
                    "log2fc": 0.0, 
                    "go": "", 
                    "regulate": "no test", 
                    "HS_2_tpm": 0.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "HS_tpm": 0.0, 
                    "HS_1_tpm": 0.0, 
                    "LS_1_count": 0.0, 
                    "LS_2_count": 0.0, 
                    "KO_name": "", 
                    "LS_3_tpm": 0.0, 
                    "nr": "XP_042887426.1(anti-sigma-I factor RsgI2-like [Penaeus japonicus])", 
                    "HS_3_count": 0.0, 
                    "cog": "", 
                    "fc": 1.0, 
                    "significant": "no test", 
                    "LS_1_tpm": 0.0, 
                    "entrez": 122263149.0, 
                    "pfam": "", 
                    "HS_1_count": 0.0, 
                    "length": 999, 
                    "HS_2_count": 0.0, 
                    "Gene id": "gene-LOC122263149", 
                    "pvalue": 1.0
                }, 
                {
                    "cog_description": "ENOG4111HBB(TM2 domain)", 
                    "padjust": 0.996897092228, 
                    "LS_2_tpm": 16.82, 
                    "Gene description": "TM2 domain-containing protein CG11103-like", 
                    "LS_3_count": 444.21, 
                    "swissprot": "sp|Q9VY86|TM2D2_DROME(TM2 domain-containing protein CG11103 OS=Drosophila melanogaster OX=7227 GN=CG11103 PE=2 SV=3)", 
                    "HS_3_tpm": 5.07, 
                    "LS_tpm": 17.4466666667, 
                    "Gene name": "LOC122262076", 
                    "log2fc": 0.0044449575688900005, 
                    "go": "", 
                    "regulate": "up", 
                    "HS_2_tpm": 13.45, 
                    "paths": "", 
                    "KO_id": "", 
                    "HS_tpm": 11.83, 
                    "HS_1_tpm": 16.97, 
                    "LS_1_count": 274.68, 
                    "LS_2_count": 403.75, 
                    "KO_name": "", 
                    "LS_3_tpm": 20.62, 
                    "nr": "XP_042885936.1(TM2 domain-containing protein CG11103-like [Penaeus japonicus])", 
                    "HS_3_count": 162.99, 
                    "cog": "ENOG4111HBB(S:Function unknown)", 
                    "fc": 1.003085761, 
                    "significant": "no", 
                    "LS_1_tpm": 14.9, 
                    "entrez": 122262076.0, 
                    "pfam": "PF05154.19(TM2:TM2 domain)", 
                    "HS_1_count": 381.29, 
                    "length": 713, 
                    "HS_2_count": 306.42, 
                    "Gene id": "gene-LOC122262076", 
                    "pvalue": 0.9902781293330001
                }, 
                {
                    "cog_description": "", 
                    "padjust": 1.0, 
                    "LS_2_tpm": 0.0, 
                    "Gene description": "uncharacterized LOC122249222", 
                    "LS_3_count": 8.0, 
                    "swissprot": "", 
                    "HS_3_tpm": 0.14, 
                    "LS_tpm": 0.0633333333333, 
                    "Gene name": "LOC122249222", 
                    "log2fc": 2.05190325367, 
                    "go": "GO:0016021(cellular_component:integral component of membrane)", 
                    "regulate": "up", 
                    "HS_2_tpm": 0.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "HS_tpm": 0.04666666666669999, 
                    "HS_1_tpm": 0.0, 
                    "LS_1_count": 0.0, 
                    "LS_2_count": 0.0, 
                    "KO_name": "", 
                    "LS_3_tpm": 0.19, 
                    "nr": "XP_042865850.1(uncharacterized protein LOC122249222 [Penaeus japonicus])", 
                    "HS_3_count": 10.0, 
                    "cog": "", 
                    "fc": 4.1465263310100005, 
                    "significant": "no", 
                    "LS_1_tpm": 0.0, 
                    "entrez": 122249222.0, 
                    "pfam": "", 
                    "HS_1_count": 0.0, 
                    "length": 3297, 
                    "HS_2_count": 0.0, 
                    "Gene id": "gene-LOC122249222", 
                    "pvalue": 0.48665599410099997
                }, 
                {
                    "cog_description": "", 
                    "padjust": 1.0, 
                    "LS_2_tpm": 0.0, 
                    "Gene description": "uncharacterized LOC122256209", 
                    "LS_3_count": 0.0, 
                    "swissprot": "", 
                    "HS_3_tpm": 0.0, 
                    "LS_tpm": 0.0, 
                    "Gene name": "LOC122256209", 
                    "log2fc": 0.0, 
                    "go": "", 
                    "regulate": "no test", 
                    "HS_2_tpm": 0.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "HS_tpm": 0.0, 
                    "HS_1_tpm": 0.0, 
                    "LS_1_count": 0.0, 
                    "LS_2_count": 0.0, 
                    "KO_name": "", 
                    "LS_3_tpm": 0.0, 
                    "nr": "XP_042876670.1(uncharacterized protein LOC122256209 [Penaeus japonicus])", 
                    "HS_3_count": 0.0, 
                    "cog": "", 
                    "fc": 1.0, 
                    "significant": "no test", 
                    "LS_1_tpm": 0.0, 
                    "entrez": 122256209.0, 
                    "pfam": "", 
                    "HS_1_count": 0.0, 
                    "length": 700, 
                    "HS_2_count": 0.0, 
                    "Gene id": "gene-LOC122256209", 
                    "pvalue": 1.0
                }, 
                {
                    "cog_description": "", 
                    "padjust": 1.0, 
                    "LS_2_tpm": 0.0, 
                    "Gene description": "keratin-associated protein 9-1-like", 
                    "LS_3_count": 0.0, 
                    "swissprot": "", 
                    "HS_3_tpm": 0.0, 
                    "LS_tpm": 0.0, 
                    "Gene name": "LOC122252304", 
                    "log2fc": 0.0, 
                    "go": "", 
                    "regulate": "no test", 
                    "HS_2_tpm": 0.0, 
                    "paths": "", 
                    "KO_id": "", 
                    "HS_tpm": 0.0, 
                    "HS_1_tpm": 0.0, 
                    "LS_1_count": 0.0, 
                    "LS_2_count": 0.0, 
                    "KO_name": "", 
                    "LS_3_tpm": 0.0, 
                    "nr": "XP_042870632.1(keratin-associated protein 9-1-like [Penaeus japonicus])", 
                    "HS_3_count": 0.0, 
                    "cog": "", 
                    "fc": 1.0, 
                    "significant": "no test", 
                    "LS_1_tpm": 0.0, 
                    "entrez": 122252304.0, 
                    "pfam": "", 
                    "HS_1_count": 0.0, 
                    "length": 543, 
                    "HS_2_count": 0.0, 
                    "Gene id": "gene-LOC122252304", 
                    "pvalue": 1.0
                }, 
                {
                    "cog_description": "ENOG410XNQK(Transporter)", 
                    "padjust": 1.0, 
                    "LS_2_tpm": 0.0, 
                    "Gene description": "facilitated trehalose transporter Tret1-like", 
                    "LS_3_count": 0.0, 
                    "swissprot": "sp|B0WC46|TRET1_CULQU(Facilitated trehalose transporter Tret1 OS=Culex quinquefasciatus OX=7176 GN=Tret1 PE=3 SV=1)", 
                    "HS_3_tpm": 0.0, 
                    "LS_tpm": 0.0, 
                    "Gene name": "LOC122262218", 
                    "log2fc": 0.0, 
                    "go": "GO:0022857(molecular_function:transmembrane transporter activity); GO:0016021(cellular_component:integral component of membrane); GO:0008643(biological_process:carbohydrate transport)", 
                    "regulate": "no test", 
                    "HS_2_tpm": 0.0, 
                    "paths": "", 
                    "KO_id": "K14258", 
                    "HS_tpm": 0.0, 
                    "HS_1_tpm": 0.0, 
                    "LS_1_count": 0.0, 
                    "LS_2_count": 0.0, 
                    "KO_name": "TRET1", 
                    "LS_3_tpm": 0.0, 
                    "nr": "XP_042886117.1(facilitated trehalose transporter Tret1-like [Penaeus japonicus])", 
                    "HS_3_count": 0.0, 
                    "cog": "ENOG410XNQK(G:Carbohydrate transport and metabolism)", 
                    "fc": 1.0, 
                    "significant": "no test", 
                    "LS_1_tpm": 0.0, 
                    "entrez": 122262218.0, 
                    "pfam": "PF00083.27(Sugar_tr:Sugar (and other) transporter); PF07690.19(MFS_1:Major Facilitator Superfamily)", 
                    "HS_1_count": 0.0, 
                    "length": 690, 
                    "HS_2_count": 0.0, 
                    "Gene id": "gene-LOC122262218", 
                    "pvalue": 1.0
                }, 
                {
                    "cog_description": "ENOG410Z9EP(insulin receptor substrate)", 
                    "padjust": 0.289602433911, 
                    "LS_2_tpm": 13.68, 
                    "Gene description": "insulin receptor substrate 2-like, transcript variant X1", 
                    "LS_3_count": 2371.0, 
                    "swissprot": "sp|Q9XTN2|IRS1_DROME(Insulin receptor substrate 1 OS=Drosophila melanogaster OX=7227 GN=chico PE=1 SV=1)", 
                    "HS_3_tpm": 1.83, 
                    "LS_tpm": 20.6233333333, 
                    "Gene name": "LOC122248311", 
                    "log2fc": -0.785933601339, 
                    "go": "", 
                    "regulate": "down", 
                    "HS_2_tpm": 6.79, 
                    "paths": "map05206(MicroRNAs in cancer); map04935(Growth hormone synthesis, secretion and action); map04931(Insulin resistance); map04150(mTOR signaling pathway); map05010(Alzheimer disease); map04960(Aldosterone-regulated sodium reabsorption); map04151(PI3K-Akt signaling pathway); map04068(FoxO signaling pathway); map04920(Adipocytokine signaling pathway); map04923(Regulation of lipolysis in adipocytes); map04910(Insulin signaling pathway); map04152(AMPK signaling pathway); map04022(cGMP-PKG signaling pathway); map04213(Longevity regulating pathway - multiple species); map04212(Longevity regulating pathway - worm); map04211(Longevity regulating pathway); map05415(Diabetic cardiomyopathy); map04932(Non-alcoholic fatty liver disease); map04722(Neurotrophin signaling pathway); map04930(Type II diabetes mellitus); map04140(Autophagy - animal)", 
                    "KO_id": "K07187;K16172", 
                    "HS_tpm": 8.476666666669999, 
                    "HS_1_tpm": 16.81, 
                    "LS_1_count": 1752.0, 
                    "LS_2_count": 1318.0, 
                    "KO_name": "IRS2;IRS1", 
                    "LS_3_tpm": 28.64, 
                    "nr": "XP_042864161.1(dentin sialophosphoprotein-like isoform X1 [Penaeus japonicus])", 
                    "HS_3_count": 254.0, 
                    "cog": "ENOG410Z9EP(T:Signal transduction mechanisms)", 
                    "fc": 0.579976519504, 
                    "significant": "no", 
                    "LS_1_tpm": 19.55, 
                    "entrez": 122248311.0, 
                    "pfam": "PF02174.20(IRS:PTB domain (IRS-1 type)); PF00169.32(PH:PH domain)", 
                    "HS_1_count": 1570.0, 
                    "length": 6358, 
                    "HS_2_count": 850.0, 
                    "Gene id": "gene-LOC122248311", 
                    "pvalue": 0.055202614312699995
                }
            ]
        }, 
        "table_5657": {
            "table_header": [
                {
                    "field": "Sample", 
                    "label": "Sample"
                }, 
                {
                    "field": "Total_reads", 
                    "label": "Total_reads"
                }, 
                {
                    "field": "Total_mapped", 
                    "label": "Total_mapped"
                }, 
                {
                    "field": "Multiple_mapped", 
                    "label": "Multiple_mapped"
                }, 
                {
                    "field": "Unique_mapped", 
                    "label": "Unique_mapped"
                }
            ], 
            "table": [
                {
                    "Sample": "HS_1", 
                    "Total_mapped": "37947421(89.93%)", 
                    "Total_reads": 42195900, 
                    "Unique_mapped": "35629979(84.44%)", 
                    "Multiple_mapped": "2317442(5.49%)"
                }, 
                {
                    "Sample": "HS_2", 
                    "Total_mapped": "39942127(91.83%)", 
                    "Total_reads": 43495944, 
                    "Unique_mapped": "37516789(86.25%)", 
                    "Multiple_mapped": "2425338(5.58%)"
                }, 
                {
                    "Sample": "HS_3", 
                    "Total_mapped": "40897018(94.23%)", 
                    "Total_reads": 43402336, 
                    "Unique_mapped": "38251865(88.13%)", 
                    "Multiple_mapped": "2645153(6.09%)"
                }, 
                {
                    "Sample": "LS_1", 
                    "Total_mapped": "38128643(90.95%)", 
                    "Total_reads": 41921834, 
                    "Unique_mapped": "36272876(86.53%)", 
                    "Multiple_mapped": "1855767(4.43%)"
                }, 
                {
                    "Sample": "LS_2", 
                    "Total_mapped": "39982250(91.57%)", 
                    "Total_reads": 43664664, 
                    "Unique_mapped": "38178803(87.44%)", 
                    "Multiple_mapped": "1803447(4.13%)"
                }, 
                {
                    "Sample": "LS_3", 
                    "Total_mapped": "37793160(89.61%)", 
                    "Total_reads": 42173110, 
                    "Unique_mapped": "35948146(85.24%)", 
                    "Multiple_mapped": "1845014(4.37%)"
                }
            ]
        }, 
        "table_5547": {
            "table_header": [
                {
                    "field": "Depth", 
                    "label": "Depth"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "HS_2": 196711, 
                    "HS_3": 143410, 
                    "HS_1": 226379, 
                    "Depth": "<=30", 
                    "LS_2": 210882, 
                    "LS_3": 254723, 
                    "LS_1": 214626
                }, 
                {
                    "HS_2": 44559, 
                    "HS_3": 25996, 
                    "HS_1": 65517, 
                    "Depth": "31-100", 
                    "LS_2": 58969, 
                    "LS_3": 93837, 
                    "LS_1": 50223
                }, 
                {
                    "HS_2": 10917, 
                    "HS_3": 6788, 
                    "HS_1": 14901, 
                    "Depth": "101-200", 
                    "LS_2": 15490, 
                    "LS_3": 22995, 
                    "LS_1": 12539
                }, 
                {
                    "HS_2": 3416, 
                    "HS_3": 2408, 
                    "HS_1": 4994, 
                    "Depth": "201-300", 
                    "LS_2": 5352, 
                    "LS_3": 7159, 
                    "LS_1": 4181
                }, 
                {
                    "HS_2": 1828, 
                    "HS_3": 1293, 
                    "HS_1": 2280, 
                    "Depth": "301-400", 
                    "LS_2": 2333, 
                    "LS_3": 3212, 
                    "LS_1": 1959
                }, 
                {
                    "HS_2": 1104, 
                    "HS_3": 883, 
                    "HS_1": 1336, 
                    "Depth": "401-500", 
                    "LS_2": 1459, 
                    "LS_3": 1933, 
                    "LS_1": 1058
                }, 
                {
                    "HS_2": 3738, 
                    "HS_3": 2956, 
                    "HS_1": 4140, 
                    "Depth": ">500", 
                    "LS_2": 4316, 
                    "LS_3": 5067, 
                    "LS_1": 3702
                }
            ]
        }, 
        "table_5545": {
            "table_header": [
                {
                    "field": "Region", 
                    "label": "Region"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "Region": ".", 
                    "HS_2": 0, 
                    "HS_3": 0, 
                    "HS_1": 0, 
                    "LS_2": 0, 
                    "LS_3": 0, 
                    "LS_1": 0
                }, 
                {
                    "Region": "UTR3", 
                    "HS_2": 63186, 
                    "HS_3": 47547, 
                    "HS_1": 72478, 
                    "LS_2": 75421, 
                    "LS_3": 86140, 
                    "LS_1": 67702
                }, 
                {
                    "Region": "UTR5", 
                    "HS_2": 11537, 
                    "HS_3": 8298, 
                    "HS_1": 13848, 
                    "LS_2": 10767, 
                    "LS_3": 16477, 
                    "LS_1": 10646
                }, 
                {
                    "Region": "UTR5;UTR3", 
                    "HS_2": 30, 
                    "HS_3": 26, 
                    "HS_1": 26, 
                    "LS_2": 29, 
                    "LS_3": 30, 
                    "LS_1": 28
                }, 
                {
                    "Region": "downstream", 
                    "HS_2": 12413, 
                    "HS_3": 7945, 
                    "HS_1": 15998, 
                    "LS_2": 16279, 
                    "LS_3": 19616, 
                    "LS_1": 15962
                }, 
                {
                    "Region": "exonic", 
                    "HS_2": 102541, 
                    "HS_3": 74415, 
                    "HS_1": 121056, 
                    "LS_2": 106306, 
                    "LS_3": 147976, 
                    "LS_1": 101177
                }, 
                {
                    "Region": "exonic;splicing", 
                    "HS_2": 8, 
                    "HS_3": 8, 
                    "HS_1": 8, 
                    "LS_2": 8, 
                    "LS_3": 6, 
                    "LS_1": 8
                }, 
                {
                    "Region": "intergenic", 
                    "HS_2": 23101, 
                    "HS_3": 14241, 
                    "HS_1": 32159, 
                    "LS_2": 33481, 
                    "LS_3": 43412, 
                    "LS_1": 34808
                }, 
                {
                    "Region": "intronic", 
                    "HS_2": 15445, 
                    "HS_3": 8142, 
                    "HS_1": 20911, 
                    "LS_2": 15054, 
                    "LS_3": 23609, 
                    "LS_1": 17848
                }, 
                {
                    "Region": "ncRNA_UTR3", 
                    "HS_2": 105, 
                    "HS_3": 80, 
                    "HS_1": 118, 
                    "LS_2": 116, 
                    "LS_3": 119, 
                    "LS_1": 95
                }, 
                {
                    "Region": "ncRNA_UTR5", 
                    "HS_2": 26, 
                    "HS_3": 18, 
                    "HS_1": 31, 
                    "LS_2": 18, 
                    "LS_3": 38, 
                    "LS_1": 21
                }, 
                {
                    "Region": "ncRNA_exonic", 
                    "HS_2": 8370, 
                    "HS_3": 6176, 
                    "HS_1": 9909, 
                    "LS_2": 9492, 
                    "LS_3": 11412, 
                    "LS_1": 8697
                }, 
                {
                    "Region": "ncRNA_intronic", 
                    "HS_2": 1404, 
                    "HS_3": 792, 
                    "HS_1": 1949, 
                    "LS_2": 1515, 
                    "LS_3": 2055, 
                    "LS_1": 1791
                }, 
                {
                    "Region": "ncRNA_splicing", 
                    "HS_2": 11, 
                    "HS_3": 4, 
                    "HS_1": 11, 
                    "LS_2": 5, 
                    "LS_3": 11, 
                    "LS_1": 10
                }, 
                {
                    "Region": "splicing", 
                    "HS_2": 41, 
                    "HS_3": 25, 
                    "HS_1": 51, 
                    "LS_2": 40, 
                    "LS_3": 54, 
                    "LS_1": 40
                }, 
                {
                    "Region": "upstream", 
                    "HS_2": 866, 
                    "HS_3": 465, 
                    "HS_1": 1129, 
                    "LS_2": 882, 
                    "LS_3": 1367, 
                    "LS_1": 940
                }, 
                {
                    "Region": "upstream;downstream", 
                    "HS_2": 279, 
                    "HS_3": 151, 
                    "HS_1": 315, 
                    "LS_2": 287, 
                    "LS_3": 379, 
                    "LS_1": 303
                }, 
                {
                    "Region": "total", 
                    "HS_2": 239363, 
                    "HS_3": 168333, 
                    "HS_1": 289997, 
                    "LS_2": 269700, 
                    "LS_3": 352701, 
                    "LS_1": 260076
                }
            ]
        }, 
        "table_5543": {
            "table_header": [
                {
                    "field": "type", 
                    "label": "type"
                }, 
                {
                    "field": "HS_1", 
                    "label": "HS_1"
                }, 
                {
                    "field": "HS_2", 
                    "label": "HS_2"
                }, 
                {
                    "field": "HS_3", 
                    "label": "HS_3"
                }, 
                {
                    "field": "LS_1", 
                    "label": "LS_1"
                }, 
                {
                    "field": "LS_2", 
                    "label": "LS_2"
                }, 
                {
                    "field": "LS_3", 
                    "label": "LS_3"
                }
            ], 
            "table": [
                {
                    "HS_2": 36402, 
                    "HS_3": 25789, 
                    "HS_1": 43892, 
                    "LS_2": 40499, 
                    "LS_3": 52622, 
                    "LS_1": 40048, 
                    "type": "A/G"
                }, 
                {
                    "HS_2": 9355, 
                    "HS_3": 6660, 
                    "HS_1": 11489, 
                    "LS_2": 10643, 
                    "LS_3": 13683, 
                    "LS_1": 10413, 
                    "type": "A/C"
                }, 
                {
                    "HS_2": 40790, 
                    "HS_3": 28769, 
                    "HS_1": 49443, 
                    "LS_2": 45912, 
                    "LS_3": 61162, 
                    "LS_1": 43596, 
                    "type": "C/T"
                }, 
                {
                    "HS_2": 41354, 
                    "HS_3": 29045, 
                    "HS_1": 50150, 
                    "LS_2": 46511, 
                    "LS_3": 61911, 
                    "LS_1": 43846, 
                    "type": "G/A"
                }, 
                {
                    "HS_2": 6398, 
                    "HS_3": 4549, 
                    "HS_1": 7719, 
                    "LS_2": 7038, 
                    "LS_3": 9450, 
                    "LS_1": 6901, 
                    "type": "G/C"
                }, 
                {
                    "HS_2": 10173, 
                    "HS_3": 7088, 
                    "HS_1": 12503, 
                    "LS_2": 11475, 
                    "LS_3": 15054, 
                    "LS_1": 11174, 
                    "type": "C/A"
                }, 
                {
                    "HS_2": 14993, 
                    "HS_3": 10307, 
                    "HS_1": 18246, 
                    "LS_2": 17507, 
                    "LS_3": 22175, 
                    "LS_1": 16910, 
                    "type": "A/T"
                }, 
                {
                    "HS_2": 6451, 
                    "HS_3": 4549, 
                    "HS_1": 7870, 
                    "LS_2": 7193, 
                    "LS_3": 9640, 
                    "LS_1": 7031, 
                    "type": "C/G"
                }, 
                {
                    "HS_2": 10159, 
                    "HS_3": 7091, 
                    "HS_1": 12391, 
                    "LS_2": 11593, 
                    "LS_3": 15209, 
                    "LS_1": 11279, 
                    "type": "G/T"
                }, 
                {
                    "HS_2": 36630, 
                    "HS_3": 26003, 
                    "HS_1": 44184, 
                    "LS_2": 40620, 
                    "LS_3": 52928, 
                    "LS_1": 40080, 
                    "type": "T/C"
                }
            ]
        }, 
        "table_5629": {
            "table_header": [
                {
                    "field": "Class code", 
                    "label": "Class code"
                }, 
                {
                    "field": "Description", 
                    "label": "Description"
                }, 
                {
                    "field": "Number", 
                    "label": "Number"
                }
            ], 
            "table": [
                {
                    "Number": 43781, 
                    "Class code": "=", 
                    "Description": "Complete match of intron chain"
                }, 
                {
                    "Number": 0, 
                    "Class code": "c", 
                    "Description": "Contained"
                }, 
                {
                    "Number": 0, 
                    "Class code": "e", 
                    "Description": "Single exon transfrag overlapping a reference exon and at least 10 bp of a reference intron,indiction a possible pre-mRNA fragment"
                }, 
                {
                    "Number": 478, 
                    "Class code": "i", 
                    "Description": "Transfrag falling entirely within a reference intron"
                }, 
                {
                    "Number": 7416, 
                    "Class code": "j", 
                    "Description": "Potentially novel isoform (fragment):at least one splice junction is shared with a reference transcript"
                }, 
                {
                    "Number": 355, 
                    "Class code": "o", 
                    "Description": "Generic exonic overlap with a referfence transcript"
                }, 
                {
                    "Number": 0, 
                    "Class code": "p", 
                    "Description": "Possible polymerase run-on fragment(within 2Kbases of a reference transcript"
                }, 
                {
                    "Number": 0, 
                    "Class code": "s", 
                    "Description": "An intron of the transfrag overlaps a reference intron on the opposite strand(likely due to read mapping errors"
                }, 
                {
                    "Number": 3061, 
                    "Class code": "u", 
                    "Description": "Unknown,intergenic transcript"
                }, 
                {
                    "Number": 283, 
                    "Class code": "x", 
                    "Description": "Exonic overlap with reference on the opposite strand"
                }, 
                {
                    "Number": 0, 
                    "Class code": "r", 
                    "Description": "Repeat. Currently determined by looking at the soft-masked reference sequence and applied to transcripts where at least 50% of the bases are lower case"
                }, 
                {
                    "Number": 0, 
                    "Class code": ".", 
                    "Description": "Tracking file only,indicates multiple classifications"
                }
            ]
        }, 
        "table_5623": {
            "table_header": [
                {
                    "field": "Species Latin Name", 
                    "label": "Species Latin Name"
                }, 
                {
                    "field": "Sample Productive Name", 
                    "label": "Sample Productive Name"
                }, 
                {
                    "field": "Sample Name", 
                    "label": "Sample Name"
                }, 
                {
                    "field": "Group Name", 
                    "label": "Group Name"
                }
            ], 
            "table": [
                {
                    "Group Name": "HS", 
                    "Sample Name": "HS_1", 
                    "Sample Productive Name": "HS_1", 
                    "Species Latin Name": "Penaeus_japonicus"
                }, 
                {
                    "Group Name": "HS", 
                    "Sample Name": "HS_2", 
                    "Sample Productive Name": "HS_2", 
                    "Species Latin Name": "Penaeus_japonicus"
                }, 
                {
                    "Group Name": "HS", 
                    "Sample Name": "HS_3", 
                    "Sample Productive Name": "HS_3", 
                    "Species Latin Name": "Penaeus_japonicus"
                }, 
                {
                    "Group Name": "LS", 
                    "Sample Name": "LS_1", 
                    "Sample Productive Name": "LS_1", 
                    "Species Latin Name": "Penaeus_japonicus"
                }, 
                {
                    "Group Name": "LS", 
                    "Sample Name": "LS_2", 
                    "Sample Productive Name": "LS_2", 
                    "Species Latin Name": "Penaeus_japonicus"
                }, 
                {
                    "Group Name": "LS", 
                    "Sample Name": "LS_3", 
                    "Sample Productive Name": "LS_3", 
                    "Species Latin Name": "Penaeus_japonicus"
                }
            ]
        }, 
        "table_5621": {
            "table_header": [
                {
                    "field": "Chromosome", 
                    "label": "Chromosome"
                }, 
                {
                    "field": "Length(MB)", 
                    "label": "Length(MB)"
                }, 
                {
                    "field": "GC%", 
                    "label": "GC%"
                }, 
                {
                    "field": "Gene", 
                    "label": "Gene"
                }, 
                {
                    "field": "ProteinCoding", 
                    "label": "ProteinCoding"
                }, 
                {
                    "field": "OtherRNA", 
                    "label": "OtherRNA"
                }, 
                {
                    "field": "Pseudogene", 
                    "label": "Pseudogene"
                }
            ], 
            "table": [
                {
                    "Pseudogene": "0", 
                    "GC%": 36.3, 
                    "Length(MB)": 1.34, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "2", 
                    "Gene": "3", 
                    "Chromosome": "NW_025029446.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.41, 
                    "Length(MB)": 1.31, 
                    "OtherRNA": "3", 
                    "ProteinCoding": "18", 
                    "Gene": "21", 
                    "Chromosome": "NW_025029447.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.43, 
                    "Length(MB)": 1.31, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "21", 
                    "Gene": "21", 
                    "Chromosome": "NW_025029448.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 39.55, 
                    "Length(MB)": 1.3, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "6", 
                    "Gene": "6", 
                    "Chromosome": "NW_025029449.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 39.77, 
                    "Length(MB)": 1.28, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "7", 
                    "Gene": "7", 
                    "Chromosome": "NW_025029450.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.98, 
                    "Length(MB)": 1.27, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "12", 
                    "Gene": "13", 
                    "Chromosome": "NW_025029451.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.04, 
                    "Length(MB)": 1.24, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "13", 
                    "Gene": "15", 
                    "Chromosome": "NW_025029452.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 36.97, 
                    "Length(MB)": 1.23, 
                    "OtherRNA": "5", 
                    "ProteinCoding": "10", 
                    "Gene": "15", 
                    "Chromosome": "NW_025029453.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.32, 
                    "Length(MB)": 1.22, 
                    "OtherRNA": "27", 
                    "ProteinCoding": "14", 
                    "Gene": "41", 
                    "Chromosome": "NW_025029454.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.72, 
                    "Length(MB)": 1.21, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "32", 
                    "Gene": "32", 
                    "Chromosome": "NW_025029455.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.36, 
                    "Length(MB)": 1.21, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "14", 
                    "Gene": "15", 
                    "Chromosome": "NW_025029456.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.45, 
                    "Length(MB)": 1.15, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "19", 
                    "Gene": "19", 
                    "Chromosome": "NW_025029457.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.13, 
                    "Length(MB)": 1.14, 
                    "OtherRNA": "3", 
                    "ProteinCoding": "30", 
                    "Gene": "33", 
                    "Chromosome": "NW_025029458.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 36.4, 
                    "Length(MB)": 1.13, 
                    "OtherRNA": "10", 
                    "ProteinCoding": "4", 
                    "Gene": "14", 
                    "Chromosome": "NW_025029459.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.97, 
                    "Length(MB)": 1.11, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "5", 
                    "Gene": "6", 
                    "Chromosome": "NW_025029460.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.91, 
                    "Length(MB)": 1.09, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "16", 
                    "Gene": "18", 
                    "Chromosome": "NW_025029461.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 42.24, 
                    "Length(MB)": 1.09, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "2", 
                    "Gene": "2", 
                    "Chromosome": "NW_025029462.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.94, 
                    "Length(MB)": 1.07, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "4", 
                    "Gene": "4", 
                    "Chromosome": "NW_025029463.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 36.35, 
                    "Length(MB)": 1.06, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "10", 
                    "Gene": "10", 
                    "Chromosome": "NW_025029464.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 33.88, 
                    "Length(MB)": 1.05, 
                    "OtherRNA": "14", 
                    "ProteinCoding": "18", 
                    "Gene": "32", 
                    "Chromosome": "NW_025029465.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.15, 
                    "Length(MB)": 1.04, 
                    "OtherRNA": "9", 
                    "ProteinCoding": "4", 
                    "Gene": "13", 
                    "Chromosome": "NW_025029466.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.73, 
                    "Length(MB)": 1.04, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "21", 
                    "Gene": "21", 
                    "Chromosome": "NW_025029467.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.1, 
                    "Length(MB)": 1.02, 
                    "OtherRNA": "5", 
                    "ProteinCoding": "12", 
                    "Gene": "17", 
                    "Chromosome": "NW_025029468.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 42.62, 
                    "Length(MB)": 1.02, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "4", 
                    "Gene": "5", 
                    "Chromosome": "NW_025029469.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.15, 
                    "Length(MB)": 1.01, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "24", 
                    "Gene": "24", 
                    "Chromosome": "NW_025029470.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.67, 
                    "Length(MB)": 1.01, 
                    "OtherRNA": "13", 
                    "ProteinCoding": "22", 
                    "Gene": "35", 
                    "Chromosome": "NW_025029471.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 33.73, 
                    "Length(MB)": 1.01, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "22", 
                    "Gene": "22", 
                    "Chromosome": "NW_025029472.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.13, 
                    "Length(MB)": 1.0, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "15", 
                    "Gene": "16", 
                    "Chromosome": "NW_025029473.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.74, 
                    "Length(MB)": 1.0, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "17", 
                    "Gene": "18", 
                    "Chromosome": "NW_025029474.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.45, 
                    "Length(MB)": 0.99, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "5", 
                    "Gene": "5", 
                    "Chromosome": "NW_025029475.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 32.59, 
                    "Length(MB)": 0.98, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "8", 
                    "Gene": "8", 
                    "Chromosome": "NW_025029476.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.84, 
                    "Length(MB)": 0.97, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "4", 
                    "Gene": "4", 
                    "Chromosome": "NW_025029477.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 37.74, 
                    "Length(MB)": 0.96, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "8", 
                    "Gene": "8", 
                    "Chromosome": "NW_025029478.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.82, 
                    "Length(MB)": 0.96, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "9", 
                    "Gene": "10", 
                    "Chromosome": "NW_025029479.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.17, 
                    "Length(MB)": 0.95, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "9", 
                    "Gene": "10", 
                    "Chromosome": "NW_025029480.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 39.17, 
                    "Length(MB)": 0.95, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "6", 
                    "Gene": "8", 
                    "Chromosome": "NW_025029481.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.31, 
                    "Length(MB)": 0.95, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "14", 
                    "Gene": "15", 
                    "Chromosome": "NW_025029482.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.24, 
                    "Length(MB)": 0.95, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "16", 
                    "Gene": "17", 
                    "Chromosome": "NW_025029483.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 39.71, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "3", 
                    "Gene": "3", 
                    "Chromosome": "NW_025029484.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.84, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "9", 
                    "Gene": "11", 
                    "Chromosome": "NW_025029485.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 39.28, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "9", 
                    "Gene": "9", 
                    "Chromosome": "NW_025029486.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.35, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "11", 
                    "Gene": "13", 
                    "Chromosome": "NW_025029487.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 34.59, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "6", 
                    "Gene": "6", 
                    "Chromosome": "NW_025029488.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.41, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "3", 
                    "Gene": "3", 
                    "Chromosome": "NW_025029489.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 38.45, 
                    "Length(MB)": 0.94, 
                    "OtherRNA": "1", 
                    "ProteinCoding": "13", 
                    "Gene": "14", 
                    "Chromosome": "NW_025029490.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 33.42, 
                    "Length(MB)": 0.93, 
                    "OtherRNA": "5", 
                    "ProteinCoding": "12", 
                    "Gene": "17", 
                    "Chromosome": "NW_025029491.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 29.67, 
                    "Length(MB)": 0.93, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "25", 
                    "Gene": "27", 
                    "Chromosome": "NW_025029492.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 36.29, 
                    "Length(MB)": 0.93, 
                    "OtherRNA": "2", 
                    "ProteinCoding": "21", 
                    "Gene": "23", 
                    "Chromosome": "NW_025029493.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 35.63, 
                    "Length(MB)": 0.92, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "9", 
                    "Gene": "9", 
                    "Chromosome": "NW_025029494.1"
                }, 
                {
                    "Pseudogene": "0", 
                    "GC%": 40.12, 
                    "Length(MB)": 0.92, 
                    "OtherRNA": "0", 
                    "ProteinCoding": "7", 
                    "Gene": "7", 
                    "Chromosome": "NW_025029495.1"
                }
            ]
        }
    }
}